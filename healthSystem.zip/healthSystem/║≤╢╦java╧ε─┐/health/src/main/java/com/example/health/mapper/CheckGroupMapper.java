package com.example.health.mapper;

import com.example.health.entity.CheckGroup;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public interface CheckGroupMapper {
    public void add(CheckGroup checkGroup);

    public void setCheckGroupAndCheckItem(Map<String, Integer> map);
  //  public Page<CheckGroup> findByCondition(String queryString);
    public CheckGroup findById(Integer id);

    public int edit(CheckGroup checkGroup);

    public void deleteAssociation(Integer checkgroupId);

    public List<CheckGroup> findAll();

    public List<CheckGroup> setmealToGroup(Integer id);

    public int delete(int id);

    public int save(CheckGroup checkGroup);

    public int insertToSetmeal(int setmeal_id,int checkgroup_id);

    public int deleteToSetmeal(int setmeal_id,int checkgroup_id);


}
