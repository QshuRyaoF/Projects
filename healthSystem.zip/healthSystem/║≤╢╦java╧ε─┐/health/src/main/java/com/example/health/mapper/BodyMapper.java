package com.example.health.mapper;

import com.example.health.entity.Body;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface BodyMapper {
    /**
     * 新增随体制测评
     * @param body
     * @return
     * **/
    int save(Body body);

    /**
     * 编辑随访日记信息
     * @param body
     * @return
     * **/
    int update(Body body);

    /**
     * 删除随访日记信息
     * @param fileNo
     * @return
     * **/
    int delete(int fileNo);

    /**
     * 查询所有日记信息
     * @return
     * **/
    List<Body> selectAll();

    /**
     * 根据序号查询指定日记信息
     * @param fileNo
     * @return
     * **/
    Body getBodyInfo(int fileNo);
}
