package com.example.health.controller;

import com.example.health.entity.Menu;
import com.example.health.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@CrossOrigin
@RestController
@RequestMapping("/menu")
public class MenuController{

    @Autowired
    private MenuService menuService;

    @RequestMapping(value = "/getByRid")
    public Map findByRole(Integer id) {
        Map map = new HashMap<>();
        List list=menuService.findByRole(id);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/getAll")
    public Map findMenus() {
        Map map = new HashMap<>();
        List list=menuService.findMenus();
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/getByNameOrLkurl")
    public Map findByNameAndLkurl(String name, String linkUrl) {
        Map map = new HashMap<>();
        List list=menuService.findByNameAndLkurl(name,linkUrl);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/add")
    public Map add(Menu menu) {
        Map map = new HashMap<>();
        int res=menuService.add(menu);
        if(res>=1){
            map.put("code","200");
            map.put("msg","添加成功");
        }else{
            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }

    @RequestMapping(value = "/getByid")
    public Map findById(Integer id) {
        Map map = new HashMap<>();
        Menu menu=menuService.findById(id);
        if(menu!=null){
            List list=new ArrayList<>();
            list.add(menu);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/edit")
    public Map edit(Menu menu) {
        Map map = new HashMap<>();
        int res =menuService.edit(menu);
        if(res>=1){
            map.put("code","200");
            map.put("msg","更新成功");
        }else{
            map.put("code","201");
            map.put("msg","更新失败");
        }
        return map;
    }

    @RequestMapping(value = "/delete")
    public Map delete(Integer id) {
        Map map = new HashMap<>();
        int res =menuService.delete(id);
        if(res>=1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/findByParentId")
    public Map findByParentId(Integer id) {
        Map map = new HashMap<>();
        List list=menuService.findByParentId(id);
        if(list!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/deleteConnection4RoleBymid")
    public Map deleteConnection4RoleBymid(Integer id) {
        Map map = new HashMap<>();
        int res =menuService.deleteConnection4RoleBymid(id);
        if(res>=1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/findAllFistMenusById")
    public Map findAllFistMenusById(Integer id) {
        Map map = new HashMap<>();
        LinkedHashSet linkedHashSet=menuService.findAllFistMenusById(id);
        if(linkedHashSet!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",linkedHashSet);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/findSecondMenusByMenuId")
    public Map findSecondMenusByMenuId(Integer id, Integer menuId) {
        Map map = new HashMap<>();
        List list=menuService.findSecondMenusByMenuId(id,menuId);
        if(list!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
}
