package com.example.health.entity;
//创建实体类
public class Dairy {
    private int serialNum;
    private String returnDate;
    private String byinterVention;
    private String reviewStaff;
    private String waY;
    private String reviewContent;
    private String backInfo;
    private String processRe;

    public int getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(int serialNum) {
        this.serialNum = serialNum;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public String getByinterVention() {
        return byinterVention;
    }

    public void setByinterVention(String byinterVention) {
        this.byinterVention = byinterVention;
    }

    public String getReviewStaff() {
        return reviewStaff;
    }

    public void setReviewStaff(String reviewStaff) {
        this.reviewStaff = reviewStaff;
    }

    public String getWaY() {
        return waY;
    }

    public void setWaY(String waY) {
        this.waY = waY;
    }

    public String getReviewContent() {
        return reviewContent;
    }

    public void setReviewContent(String reviewContent) {
        this.reviewContent = reviewContent;
    }

    public String getBackInfo() {
        return backInfo;
    }

    public void setBackInfo(String backInfo) {
        this.backInfo = backInfo;
    }

    public String getProcessRe() {
        return processRe;
    }

    public void setProcessRe(String processRe) {
        this.processRe = processRe;
    }

    @Override
    public String toString() {
        return "Dairy{" +
                "serialNum=" + serialNum +
                ", returnDate='" + returnDate + '\'' +
                ", byinterVention='" + byinterVention + '\'' +
                ", reviewStaff='" + reviewStaff + '\'' +
                ", waY='" + waY + '\'' +
                ", reviewContent='" + reviewContent + '\'' +
                ", backInfo='" + backInfo + '\'' +
                ", processRe='" + processRe + '\'' +
                '}';
    }
}
