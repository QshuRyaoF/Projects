package com.example.health.mapper;
//DairyMapper
import com.example.health.entity.Dairy;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface DairyMapper {
    /**
     * 新增随访日记
     * @param dairy
     * @return
     * **/
    int save(Dairy dairy);

    /**
     * 编辑随访日记信息
     * @param dairy
     * @return
     * **/
    int update(Dairy dairy);

    /**
     * 删除随访日记信息
     * @param serialNum
     * @return
     * **/
    int delete(int serialNum);

    /**
     * 查询所有日记信息
     * @return
     * **/
    List<Dairy> selectAll();

    /**
     * 根据序号查询指定日记信息
     * @param serialNum
     * @return
     * **/
    Dairy getDairyInfo(int serialNum);

}
