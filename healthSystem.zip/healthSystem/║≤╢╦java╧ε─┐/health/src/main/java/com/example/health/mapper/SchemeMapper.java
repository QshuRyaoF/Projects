package com.example.health.mapper;

import com.example.health.entity.Scheme;
import com.example.health.service.impl.SchemeServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface SchemeMapper {

    List<Scheme> selectAll();

    int add(Scheme scheme);

    int delete(int id);

    int edit(Scheme scheme);

    Scheme findByid(int id);
}
