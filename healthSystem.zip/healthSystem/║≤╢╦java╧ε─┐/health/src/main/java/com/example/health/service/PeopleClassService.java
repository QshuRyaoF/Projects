package com.example.health.service;

import com.example.health.entity.Disease;
import com.example.health.entity.PeopleClass;
import com.example.health.mapper.PeopleClassMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PeopleClassService {
    
    @Autowired
    private PeopleClassMapper peopleClassMapper;

    public Integer add(PeopleClass peopleClass) {
        return peopleClassMapper.add((peopleClass));
    }


    public List<Disease> selectAll() {
        return peopleClassMapper.selectAll();
    }


    public List<Disease> selectById(Integer id) {
        return peopleClassMapper.selectById(id);
    }


    public Integer delete(Integer id) {
        return peopleClassMapper.delete(id);
    }


    public Integer update(PeopleClass peopleClass) {
        return peopleClassMapper.update(peopleClass);
    }
}
