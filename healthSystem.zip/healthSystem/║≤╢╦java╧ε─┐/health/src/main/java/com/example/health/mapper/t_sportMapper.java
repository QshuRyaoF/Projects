package com.example.health.mapper;

import com.example.health.entity.t_sport;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface t_sportMapper {
    int save(t_sport sport);
    int update(t_sport sport);
    int deleteById(int id);
    List<t_sport> selectAll();
    t_sport getInfo(int id);
}
