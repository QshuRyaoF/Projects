package com.example.health.service;

import com.example.health.entity.CheckItem;

import java.util.List;

public interface CheckItemService {
    public int add(CheckItem checkItem);
   // public PageResult findPage(QueryPageBean queryPageBean);
    public int delete(Integer id);
    public CheckItem findById(Integer id);
    public int edit(CheckItem checkItem);
    public List<CheckItem> findAll();
    public List<Integer> findCheckItemIdsByCheckGroupId(Integer checkgroupId);

    public List<CheckItem> selectByGroupId(int id);

    public int insertGroupById(int checkgroup_id , int checkitem_id);

    public int deleteGroupById(int checkgroup_id , int checkitem_id);
}
