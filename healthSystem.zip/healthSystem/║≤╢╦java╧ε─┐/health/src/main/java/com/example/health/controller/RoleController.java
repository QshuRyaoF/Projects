package com.example.health.controller;

import com.example.health.entity.Role;
import com.example.health.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@CrossOrigin
@RestController
@RequestMapping("/role")
public class RoleController {
    @Autowired
    private RoleService roleService;

    //查询用户所有角色
    @RequestMapping(value = "/roles4user")
    public Map findByUserId(Integer userId) {
        Map map = new HashMap<>();
        List list=roleService.findByUserId(userId);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    //查询所有角色
    @RequestMapping(value = "getAll")
    public Map findAllRoles() {
        Map map = new HashMap<>();
        List list=roleService.findAllRoles();
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
    //通过用户名或关键字查询角色
    @RequestMapping(value = "/getByNameOrKd")
    public Map findByName2Kd(String name, String keyword) {
        Map map = new HashMap<>();
        List list=roleService.findByName2Kd(name,keyword);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
    //添加角色
    @RequestMapping(value = "/add")
    public Map add(Role role) {
        Map map = new HashMap<>();
        roleService.add(role);
        map.put("code","200");
        map.put("msg","添加成功");
        return map;
    }
    //给角色添加权限
    @RequestMapping(value = "/addPermission")
    public Map addPermissionAndRole(Integer roleId, Integer permissionId) {
        Map map = new HashMap<>();
        roleService.addPermissionAndRole(roleId,permissionId);
        map.put("code","200");
        map.put("msg","添加成功");
        return map;
    }
    // 给角色添加菜单
    @RequestMapping(value = "/addMenu")
    public Map addMenuAndRole(Integer roleId, Integer menuId) {
        Map map = new HashMap<>();
        roleService.addMenuAndRole(roleId,menuId);
        map.put("code","200");
        map.put("msg","添加成功");
        return map;
    }
    //通过角色id查询所有与他有关的权限id
    @RequestMapping(value = "/Pid4Rid")
    public Map findPermissionIdByrid(Integer rId) {
        Map map = new HashMap<>();
        List list=roleService.findPermissionIdByrid(rId);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
    //通过角色id查询所有与他有关的菜单id
    @RequestMapping(value = "/getAllMenu4Rid")
    public Map findMenuIdByrid(Integer rId) {
        Map map = new HashMap<>();
        List list=roleService.findMenuIdByrid(rId);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
    //通过角色id修改已有的角色
    @RequestMapping(value = "/update")
    public Map update(Role role) {
        Map map = new HashMap<>();
        roleService.update(role);
        map.put("code","200");
        map.put("msg","更新成功");
        return map;
    }
    //通过觉色id删除关联的权限id
    @RequestMapping(value = "/deleteConnection4PermissionByrid")
    public Map deleteConnection4PermissionByrid(Integer roleId) {
        Map map = new HashMap<>();
        roleService.deleteConnection4PermissionByrid(roleId);
        map.put("code","200");
        map.put("msg","删除成功");
        return map;
    }
    //通过角色id删除关联的菜单id
    @RequestMapping(value = "/deleteConnection4MenuByrid")
    public Map deleteConnection4MenuByrid(Integer roleId) {
        Map map = new HashMap<>();
        roleService.deleteConnection4MenuByrid(roleId);
        map.put("code","200");
        map.put("msg","删除成功");
        return map;
    }
    //通过角色id查找角色
    @RequestMapping(value = "/findById")
    public Map findById(Integer id) {
        Map map = new HashMap<>();
        Role role=roleService.findById(id);
        List list=new ArrayList<>();
        if(role != null){
            list.add(role);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    //通过角色id删除关联的用户
    @RequestMapping(value = "/deleteConnection4UserByrid")
    public Map deleteConnection4UserByrid(Integer id) {
        Map map = new HashMap<>();
        roleService.deleteConnection4UserByrid(id);
        map.put("code","200");
        map.put("msg","删除成功");
        return map;
    }

    //通过角色id删除角色
    @RequestMapping(value = "/delete")
    public Map deleterole(Integer id) {
        Map map = new HashMap<>();
        roleService.deleterole(id);
        map.put("code","200");
        map.put("msg","删除成功");
        return map;
    }

    //通过菜单id查询所有的角色
    @RequestMapping(value = "/findRoleByMid")
    public Map findRoleBymid(Integer id) {
        Map map = new HashMap<>();
        List list=roleService.findRoleBymid(id);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    //通过角色id查询所有的菜单
    @RequestMapping(value = "/findMenuByRId")
    public Map findMenuByRoleId(Integer roleId) {
        Map map = new HashMap<>();
        List list=roleService.findRoleBymid(roleId);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

}
