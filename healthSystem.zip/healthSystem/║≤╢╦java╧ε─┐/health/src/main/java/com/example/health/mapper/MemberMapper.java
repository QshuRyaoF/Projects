package com.example.health.mapper;

import com.example.health.entity.Member;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface MemberMapper {
    //根据手机号查询会员
    List<Member> findByTelephone(String phoneNumber);
    //新增会员
    Integer add(Member member);
    //查询指定月份之前会员总数
    Integer findMemberCountBeforeDate(String month);
    //根据日期查询会员总数
    Integer findMemberCountByDate(String today);
    //获取会员总数
    Integer findMemberTotalCount();
    //获取指定日期之后的会员总数
    Integer findMemberCountAfterDate(String thisWeekMonday);

    Integer updateByOrder(String name, String phoneNumber);

    //对健康管理师的回显
    List<String> findHealthManager();
    //新增
    Integer addMember(Member member);
    //会员的回显
    Member findMemberById(Integer memberId);
    //修改
    Integer editMember(Member member);

    Integer deleteMember(Integer id);

    //查询所有关联信息
    List<Map<String, Object>> findAllMessageById(Integer id);

    Integer update( Integer tempOrderId,String username);

    List<Member> findAll();

    Member findByEmailAndPwd(String email,String md5_password);
}
