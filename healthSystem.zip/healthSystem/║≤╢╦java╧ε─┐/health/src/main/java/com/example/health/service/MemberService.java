package com.example.health.service;

import com.example.health.entity.Member;
import com.example.health.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class MemberService  {

    @Autowired
    private MemberMapper memberMapper;
    
    public List<Member> findByTelephone(String telephone) {
        return memberMapper.findByTelephone(telephone);
    }

    
    public Integer add(Member member) {
        return memberMapper.add(member);
    }

    
    public Integer findMemberCountBeforeDate(String month) {
        return memberMapper.findMemberCountBeforeDate(month);
    }

    
    public Integer findMemberCountByDate(String today) {
        return memberMapper.findMemberCountByDate(today);
    }

    
    public Integer findMemberTotalCount() {
        return memberMapper.findMemberTotalCount();
    }

    
    public Integer findMemberCountAfterDate(String thisWeekMonday) {
        return memberMapper.findMemberCountAfterDate(thisWeekMonday);
    }

    
    public Integer updateByOrder(String name, String phoneNumber) {
        return memberMapper.updateByOrder(name,phoneNumber);
    }

    
    public List<String> findHealthManager() {
        return memberMapper.findHealthManager();
    }

    
    public Integer addMember(Member member) {
        return memberMapper.addMember(member);
    }

    
    public Member findMemberById(Integer memberId) {
        return memberMapper.findMemberById(memberId);
    }

    
    public Integer editMember(Member member) {
        return memberMapper.editMember(member);
    }

    
    public Integer deleteMember(Integer id) {
        return memberMapper.deleteMember(id);
    }

    
    public List<Map<String, Object>> findAllMessageById(Integer id) {
        return memberMapper.findAllMessageById(id);
    }

    
    public Integer update(Integer tempOrderId, String username) {
        return memberMapper.update(tempOrderId,username);
    }

    
    public List<Member> findAll() {
        return memberMapper.findAll();
    }

    
    public Member findByEmailAndPwd(String email, String md5_password) {
        return memberMapper.findByEmailAndPwd(email,md5_password);
    }
}
