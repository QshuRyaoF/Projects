package com.example.health.controller;

import com.example.health.entity.Member;
import com.example.health.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/member")
public class MemberController{

    @Autowired
    private MemberService memberService;

    @RequestMapping(value = "/findByTelephone")
    public Map findByTelephone(String phoneNumber) {
        Map map = new HashMap<>();
        List<Member> list=memberService.findByTelephone(phoneNumber);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/add")
    public Map add(Member member) {
        Map map = new HashMap<>();
        Integer res=memberService.add(member);
        if(res>=1){
            map.put("code","200");
            map.put("msg","添加成功");
        }else{
            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }

    @RequestMapping(value = "/findMemberCountBeforeDate")
    public Map findMemberCountBeforeDate(String month) {
        Map map = new HashMap<>();
        Integer res=memberService.findMemberCountBeforeDate(month);
        if(res>=1){
            List list=new ArrayList<>();
            list.add(res);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/findMemberCountByDate")
    public Map findMemberCountByDate(String today) {
        Map map = new HashMap<>();
        Integer res=memberService.findMemberCountByDate(today);
        if(res>=1){
            List list=new ArrayList<>();
            list.add(res);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/findMemberTotalCount")
    public Map findMemberTotalCount() {
        Map map = new HashMap<>();
        Integer res=memberService.findMemberTotalCount();
        if(res>=1){
            List list=new ArrayList<>();
            list.add(res);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/findMemberCountAfterDate")
    public Map findMemberCountAfterDate(String thisWeekMonday) {
        Map map = new HashMap<>();
        Integer res=memberService.findMemberCountAfterDate(thisWeekMonday);
        if(res>=1){
            List list=new ArrayList<>();
            list.add(res);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/updateByOrder")
    public Map updateByOrder(String name, String phoneNumber) {
        Map map = new HashMap<>();
        Integer res=memberService.updateByOrder(name,phoneNumber);
        if(res>=1){
            map.put("code","200");
            map.put("msg","更新成功");
        }else{
            map.put("code","201");
            map.put("msg","更新失败");
        }
        return map;
    }

    @RequestMapping(value = "/findHealthManager")
    public Map findHealthManager() {
        Map map = new HashMap<>();
        List list=memberService.findHealthManager();
        if(list!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/addMember")
    public Map addMember(Member member) {
        Map map = new HashMap<>();
        Integer res=memberService.addMember(member);
        if(res>=1){
            map.put("code","200");
            map.put("msg","添加成功");
        }else{
            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }

        @RequestMapping(value = "/findMemberById")
    public Map findMemberById(Integer memberId) {
        Map map = new HashMap<>();
        Member member=memberService.findMemberById(memberId);
        if(member!=null){
            List list=new ArrayList<>();
            list.add(member);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/editMember")
    public Map editMember(Member member) {
        Map map = new HashMap<>();
        Integer res=memberService.editMember(member);
        if(res>=1){
            map.put("code","200");
            map.put("msg","查询成功");
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/deleteMember")
    public Map deleteMember(Integer id) {
        Map map = new HashMap<>();
        Integer res=memberService.deleteMember(id);
        if(res>=1){
            map.put("code","200");
            map.put("msg","查询成功");
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/findAllMessageById")
    public Map findAllMessageById(Integer id) {
        Map map = new HashMap<>();
        List list=memberService.findAllMessageById(id);
        if(list!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/update")
    public Map update(Integer tempOrderId, String username) {
        Map map = new HashMap<>();
        Integer res=memberService.update(tempOrderId,username);
        if(res>=1){
            map.put("code","200");
            map.put("msg","查询成功");
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/selectAll")
    public Map findAll() {
        Map map = new HashMap<>();
        List list=memberService.findAll();
        if(list!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/findByEmailAndPwd")
    public Map findByEmailAndPwd(String email, String md5_password) {
        Map map = new HashMap<>();
        Member member=memberService.findByEmailAndPwd(email,md5_password);
        if(member!=null){
            List list=new ArrayList<>();
            list.add(member);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
}
