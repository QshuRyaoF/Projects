package com.example.health.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Test {

    public static void main(String[] args) {
        getConnection();

    }

    public static Connection getConnection() {
        //第一步 加载驱动
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        //第二步 获取连接
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mybatis?useUnicode=true&characterEncoding=utf-8&useSSL=true&serverTimezone=UTC", "root", "lsj20021216");
            //输出连接
            System.out.println("数据库连接成功");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("数据库连接失败");
        }
        return conn;
    }
}
