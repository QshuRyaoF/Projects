package com.example.health.entity;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;


public class Order {
    private int id;
    private int member_id;
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date orderDate;
    private String orderType;
    private String orderStatus;
    private int setmeal_id;
    private String food;
    private String sport;
    private String healthName;
    private String suggestion;
    private int address_id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public int getSetmeal_id() {
        return setmeal_id;
    }

    public void setSetmeal_id(int setmeal_id) {
        this.setmeal_id = setmeal_id;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    public String getHealthName() {
        return healthName;
    }

    public void setHealthName(String healthName) {
        this.healthName = healthName;
    }

    public String getSuggestion() {
        return suggestion;
    }

    public void setSuggestion(String suggestion) {
        this.suggestion = suggestion;
    }

    public int getAddress_id() {
        return address_id;
    }

    public void setAddress_id(int address_id) {
        this.address_id = address_id;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", member_id=" + member_id +
                ", orderDate=" + orderDate +
                ", orderType='" + orderType + '\'' +
                ", orderStatus='" + orderStatus + '\'' +
                ", setmeal_id=" + setmeal_id +
                ", food='" + food + '\'' +
                ", sport='" + sport + '\'' +
                ", healthName='" + healthName + '\'' +
                ", suggestion='" + suggestion + '\'' +
                ", address_id=" + address_id +
                '}';
    }

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }


}
