package com.example.health.entity;

public class Body {
    private int fileNo;
    private String humaName;
    private String assessTime;
    private String gentleTemper;
    private String deficiencyMass;
    private String yangQuality;
    private String yinQuality;
    private String phlWetMass;
    private String hotHumidMass;
    private String bloodQuality;
    private String qiDepressionMass;
    private String greatMass;

    public int getFileNo() {
        return fileNo;
    }

    public void setFileNo(int fileNo) {
        this.fileNo = fileNo;
    }

    public String getHumaName() {
        return humaName;
    }

    public void setHumaName(String humaName) {
        this.humaName = humaName;
    }

    public String getAssessTime() {
        return assessTime;
    }

    public void setAssessTime(String assessTime) {
        this.assessTime = assessTime;
    }

    public String getGentleTemper() {
        return gentleTemper;
    }

    public void setGentleTemper(String gentleTemper) {
        this.gentleTemper = gentleTemper;
    }

    public String getDeficiencyMass() {
        return deficiencyMass;
    }

    public void setDeficiencyMass(String deficiencyMass) {
        this.deficiencyMass = deficiencyMass;
    }

    public String getYangQuality() {
        return yangQuality;
    }

    public void setYangQuality(String yangQuality) {
        this.yangQuality = yangQuality;
    }

    public String getYinQuality() {
        return yinQuality;
    }

    public void setYinQuality(String yinQuality) {
        this.yinQuality = yinQuality;
    }

    public String getPhlWetMass() {
        return phlWetMass;
    }

    public void setPhlWetMass(String phlWetMass) {
        this.phlWetMass = phlWetMass;
    }

    public String getHotHumidMass() {
        return hotHumidMass;
    }

    public void setHotHumidMass(String hotHumidMass) {
        this.hotHumidMass = hotHumidMass;
    }

    public String getBloodQuality() {
        return bloodQuality;
    }

    public void setBloodQuality(String bloodQuality) {
        this.bloodQuality = bloodQuality;
    }

    public String getQiDepressionMass() {
        return qiDepressionMass;
    }

    public void setQiDepressionMass(String qiDepressionMass) {
        this.qiDepressionMass = qiDepressionMass;
    }

    public String getGreatMass() {
        return greatMass;
    }

    public void setGreatMass(String greatMass) {
        this.greatMass = greatMass;
    }

    @Override
    public String toString() {
        return "Body{" +
                "fileNo=" + fileNo +
                ", humaName='" + humaName + '\'' +
                ", assessTime='" + assessTime + '\'' +
                ", gentleTemper='" + gentleTemper + '\'' +
                ", deficiencyMass='" + deficiencyMass + '\'' +
                ", yangQuality='" + yangQuality + '\'' +
                ", yinQuality='" + yinQuality + '\'' +
                ", phlWetMass='" + phlWetMass + '\'' +
                ", hotHumidMass='" + hotHumidMass + '\'' +
                ", bloodQuality='" + bloodQuality + '\'' +
                ", qiDepressionMass='" + qiDepressionMass + '\'' +
                ", greatMass='" + greatMass + '\'' +
                '}';
    }
}
