package com.example.health.service.impl;

import com.example.health.entity.Body;
import com.example.health.mapper.BodyMapper;
import com.example.health.service.BodyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BodyServiceImpl implements BodyService {
    @Autowired
    public BodyMapper bodyMapper;
    public int save(Body body){
        return bodyMapper.save(body);
    }
    public int update(Body body){
        return bodyMapper.update(body);
    }
    public int delete(int fileNo){
        return bodyMapper.delete(fileNo);
    }
    public List<Body> selectAll(){
        return bodyMapper.selectAll();
    }
    public Body getBodyInfo(int fileNo){
        return bodyMapper.getBodyInfo(fileNo);
    }

}
