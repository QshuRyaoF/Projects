package com.example.health.mapper;

import com.example.health.entity.Order;
import org.apache.ibatis.annotations.Mapper;

import java.util.Date;
import java.util.List;

@Mapper
public interface OrderMapper {
    List<Order> selectAll();

    int update(Order order);

    int save(Order order);

    int delete(Order order);

    int submit(Order order);

    int max();

    //每日预约
    List<Order> dayOrder(Date orderDate);
    Order findByID(int ID);



}
