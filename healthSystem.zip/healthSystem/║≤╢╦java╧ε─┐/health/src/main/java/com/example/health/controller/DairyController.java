package com.example.health.controller;

import com.example.health.entity.Dairy;
import com.example.health.service.impl.DairyServiceIpml;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//Dairy控制块
@CrossOrigin
@Service
@RestController
@RequestMapping("testDairy")
public class DairyController {
    @Autowired
    DairyController dairyController;
    @Autowired
    DairyServiceIpml dairyService;
//    插入新日记信息
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map insert(Dairy dairy){
        Map map = new HashMap();
        int res = dairyService.save(dairy);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","chenggong");
        }
        else{
            map.put("code","201");
            map.put("msg","shibai");
        }
        return map;
    }
//  根据序号更新日记信息
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Map update(Dairy dairy){
        Map map= new HashMap();
        int res = dairyService.update(dairy);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","chenggong");
        }
        else{
            map.put("code","201");
            map.put("msg","shibai");
        }
        return map;
    }
//    根据序号删除日记信息
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    public Map delete(int serialNum){
        Map map= new HashMap();
        int res = dairyService.delete(serialNum);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","chenggong");
        }
        else{
            map.put("code","201");
            map.put("msg","shibai");
        }
        return map;
    }
//    查询所有日记信息
    @RequestMapping(value = "/selectAll",method = RequestMethod.POST)
    public Map selectAll(){
        Map map =  new HashMap();
        List<Dairy> res = dairyService.selectAll();
        if(res != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",res);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
//    根据serialNum查询单个日记信息
@RequestMapping(value = "/getDairyInfo",method = RequestMethod.GET)
//    public User getUserInfo(int id){
//        return userService.getUserInfo(id);
//    }
    public Map getUserInfo(int serialNum){
        Map map = new HashMap<>();

        Dairy dairy=dairyService.getDairyInfo(serialNum);
        List<Dairy> res = new ArrayList<Dairy>();
    //        System.out.println(user);
        if(dairy!=null){
            res.add(dairy);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",res);
        }
        else{
            map.put("code","201");
            map.put("msg","查询失败");
            map.put("data",null);
        }
        return map;
    }
}
