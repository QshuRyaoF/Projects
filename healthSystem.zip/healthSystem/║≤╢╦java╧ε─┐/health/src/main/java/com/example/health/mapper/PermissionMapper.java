package com.example.health.mapper;

import com.example.health.entity.Permission;
import com.example.health.entity.Role;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface PermissionMapper {

    /**
     * 查询角色的所有权限
     * @param rid
     * @return
     * */
    List<Permission> findByRoleId(Integer rid);

    /**
     * 添加权限
     * @param permission
     * @return
     * */
    int add(Permission permission);

    /**
     * 通过权限名或者关键字查找权限
     * @param name
     * @param keyword
     * @return
     * */
    Permission findByPmName2KeyWord(String name,String keyword);

    /**
     * 通过权限id修改已有的权限
     * @param permission
     * @return
     * */
    int edit(Permission permission);

    /**
     * 通过权限id查找角色
     * @param id
     * @return
     * */
    List<Role> findRolesByPmId(Integer id);

    /**
     * 通过权限id删除中间关联表
     * @param id
     * @return
     * */
    int deleteConnection4roleByPmId(Integer id);

    /**
     * 通过权限id删除权限
     * @param id
     * @return
     * */
    int deleteByPmId(Integer id);

    /**
     * 查询所有的权限
     * @param
     * @return
     * */
    List<Permission> findAllPermission();
    List<Permission> findById(Integer id);
}
