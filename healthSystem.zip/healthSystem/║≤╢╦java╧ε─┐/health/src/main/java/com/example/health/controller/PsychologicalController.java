package com.example.health.controller;

import com.example.health.entity.Psychological;
import com.example.health.service.impl.PsychologicalServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/Psychological")
public class PsychologicalController {
    @Autowired
    private PsychologicalServiceImpl psychologicalService;
    //添加
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map insert(Psychological psychological){
        Map map = new HashMap();
        int res = psychologicalService.insert(psychological);

        if(res >= 1){
            map.put("code","200");
            map.put("msg","添加成功");
        }else{
            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }
    //编辑
    @RequestMapping(value = "/edit",method = RequestMethod.POST)
    public Map edit(Psychological psychological){
        Map map = new HashMap();
        int res = psychologicalService.edit(psychological);

        if(res >= 1){
            map.put("code","200");
            map.put("msg","更新成功");
        }else{
            map.put("code","201");
            map.put("msg","更新失败");
        }
        return map;
    }
    //删除
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    public Map delete(int id){
        Map map = new HashMap();
        int res = psychologicalService.delete(id);

        if(res >= 1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }
    //根据id查询
    @RequestMapping(value = "/findByid",method = RequestMethod.POST)
    public Map findByid(int id){
        Map map = new HashMap();
        Psychological res = psychologicalService.findByid(id);

        if(res != null){
            map.put("code","200");
            map.put("msg","查询成功");
            List<Psychological> list = new ArrayList<>();
            list.add(res);
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
    //查询所有
    @RequestMapping(value = "/selectAll",method = RequestMethod.POST)
    public Map selectAll(){
        Map map = new HashMap();
        List<Psychological>res = psychologicalService.selectAll();

        if(res != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",res);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
}
