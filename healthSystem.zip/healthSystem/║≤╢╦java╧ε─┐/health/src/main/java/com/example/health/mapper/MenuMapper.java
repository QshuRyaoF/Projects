package com.example.health.mapper;

import com.example.health.entity.Menu;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Repository
public interface MenuMapper {

    List<Menu> findByRole(Integer id);

    List<Map<String, Integer>> findMenus();

    List<Menu> findByNameAndLkurl(String name,String linkUrl);

    int add(Menu menu);

    Menu findById(Integer id);

    int edit(Menu menu);

    int delete(Integer id);

    List<Menu> findByParentId(Integer id);

    int deleteConnection4RoleBymid(Integer id);

    LinkedHashSet<Menu> findAllFistMenusById(Integer id);

    List<Menu> findSecondMenusByMenuId(Integer id,Integer menuId);

}
