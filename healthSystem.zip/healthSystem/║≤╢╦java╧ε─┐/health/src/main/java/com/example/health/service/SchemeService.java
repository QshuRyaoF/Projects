package com.example.health.service;

import com.example.health.entity.Scheme;

import java.util.List;

public interface SchemeService {

    List<Scheme> selectAll();

    int add(Scheme scheme);

    int delete(int id);

    int edit(Scheme scheme);


    Scheme findByid(int id);
}
