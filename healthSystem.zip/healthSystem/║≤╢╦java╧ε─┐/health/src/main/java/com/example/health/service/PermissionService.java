package com.example.health.service;

import com.example.health.entity.Permission;
import com.example.health.entity.Role;
import com.example.health.mapper.PermissionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class PermissionService {

    @Autowired
    private PermissionMapper permissionMapper;

    //通过角色id查找所有权限
    public List<Permission> findByRoleId(Integer rid) {
        return permissionMapper.findByRoleId(rid);
    }

    //添加权限
    public int add(Permission permission) {
        return permissionMapper.add(permission);
    }

    //通过权限名或者关键字查找权限
    public Permission findByPmName2KeyWord(String name, String keyword) {
        return permissionMapper.findByPmName2KeyWord(name,keyword);
    }

    //通过权限id修改已有的权限
    public int edit(Permission permission) {
        return permissionMapper.edit(permission);
    }

    //通过权限id查找角色
    public List<Role> findRolesByPmId(Integer id) {
        return permissionMapper.findRolesByPmId(id);
    }

    //通过权限id删除中间关联表
    public int deleteConnection4roleByPmId(Integer id) {
        return permissionMapper.deleteConnection4roleByPmId(id);
    }

    //通过权限id删除权限
    public int deleteByPmId(Integer id) {
        return permissionMapper.deleteByPmId(id);
    }

    //查询所有的权限
    public List<Permission> findAllPermission() {
        return permissionMapper.findAllPermission();
    }
    public List<Permission> findById(Integer id){
        return permissionMapper.findById(id);
    }

}
