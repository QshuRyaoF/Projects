package com.example.health.service;
//DairyService块
import com.example.health.entity.Dairy;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface DairyService {
    int save(Dairy dairy);

    int update(Dairy dairy);

    int delete(int serialNum);

    List<Dairy> selectAll();

    Dairy getDairyInfo(int serialNum);
}
