package com.example.health.controller;

import com.example.health.entity.T_scheme;

import com.example.health.entity.User;
import com.example.health.service.T_schemeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin//解决跨域问题

@RestController
@RequestMapping("/testScheme")
public class T_schemeController {
    @Autowired
    private T_schemeService schemeService;

    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map insert(T_scheme scheme){
        T_scheme s =  schemeService.save(scheme);
        Map map = new HashMap<>();
        if(s!=null){
            map.put("code",200);
            map.put("msg","插入成功");
        }
        else{
            map.put("code",201);
            map.put("msg","插入失败");
        }
        return map;
    }

    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Map update(T_scheme scheme){
        int res=schemeService.update(scheme);
        Map map = new HashMap<>();
        if(res>=1){
            map.put("code",200);
            map.put("msg","更新成功");
        }
        else{
            map.put("code",201);
            map.put("msg","更新失败");
        }
        return map;
    }

    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Map delete(int id){
        int res=schemeService.deleteById(id);
        Map map = new HashMap<>();
        if(res>=1){
            map.put("code",200);
            map.put("msg","删除成功");
        }
        else{
            map.put("code",201);
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/selectAll",method = RequestMethod.GET)
    @ResponseBody
    public Map selectAll(){
        List<T_scheme> list = schemeService.selectAll();
        Map map = new HashMap<>();
        if(list!=null) {
            map.put("code",200);
            map.put("msg","查询成功");
            map.put("data",list);
        }
        else{
            map.put("code",201);
            map.put("msg","查询失败");
            map.put("data",null);
        }
        return map;
    }

    @RequestMapping(value = "/getInfo",method = RequestMethod.GET)
    public Map getInfo(T_scheme s){
        List<T_scheme> list = schemeService.getInfo(s);
        Map map = new HashMap<>();
        if(list!=null) {
            map.put("code",200);
            map.put("msg","查询成功");
            map.put("data",list);
        }
        else{
            map.put("code",201);
            map.put("msg","查询失败");
            map.put("data",null);
        }
        return map;
    }
}
