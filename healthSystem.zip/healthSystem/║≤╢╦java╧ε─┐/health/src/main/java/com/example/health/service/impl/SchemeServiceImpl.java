package com.example.health.service.impl;

import com.example.health.entity.Scheme;
import com.example.health.mapper.SchemeMapper;
import com.example.health.service.SchemeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SchemeServiceImpl implements SchemeService {
    @Autowired
    private SchemeMapper schemeMapper;

    @Override
    public List<Scheme> selectAll(){
        return schemeMapper.selectAll();
    }

    @Override
    public int add(Scheme scheme) {
        return schemeMapper.add(scheme);
    }

    @Override
    public int delete(int id) {
        return schemeMapper.delete(id);
    }

    @Override
    public int edit(Scheme scheme) {
        return schemeMapper.edit(scheme);
    }

    public
    Scheme findByid(int id){
        return schemeMapper.findByid(id);
    }
}
