package com.example.health.mapper;

import com.example.health.entity.Psychological;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface PsychologicalMapper {

    int insert(Psychological psychological);

    int delete(int id);

    int edit(Psychological psychological);

    List<Psychological> selectAll();

    Psychological findByid(int id);
}
