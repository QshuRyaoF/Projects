package com.example.health.controller;

import com.example.health.entity.Food;
import com.example.health.entity.User;
import com.example.health.service.FoodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin//解决跨域问题
@RestController
@RequestMapping("/testFood")
public class FoodController {
    @Autowired
    private FoodService foodService;

    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map insert(Food food){
        Food f =  foodService.save(food);
        Map map = new HashMap<>();
        if(f!=null){
            map.put("code",200);
            map.put("msg","插入成功");
        }
        else{
            map.put("code",201);
            map.put("msg","插入失败");
        }
        return map;
    }

    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Map update(Food food){
        int res=foodService.update(food);
        Map map = new HashMap<>();
        if(res>=1){
            map.put("code",200);
            map.put("msg","更新成功");
        }
        else{
            map.put("code",201);
            map.put("msg","更新失败");
        }
        return map;
    }

    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Map delete(int id){
        int res=foodService.deleteById(id);
        Map map = new HashMap<>();
        if(res>=1){
            map.put("code",200);
            map.put("msg","删除成功");
        }
        else{
            map.put("code",201);
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/selectAll",method = RequestMethod.GET)
    @ResponseBody
    public Map selectAll(){
        List<Food> list = foodService.selectAll();
        Map map = new HashMap<>();
        if(list!=null) {
            map.put("code",200);
            map.put("msg","查询成功");
            map.put("data",list);
        }
        else{
            map.put("code",201);
            map.put("msg","查询失败");
            map.put("data",null);
        }
        return map;
    }

    @RequestMapping(value = "/getInfo",method = RequestMethod.GET)
    public Map getInfo(int id){
        Food food = foodService.getInfo(id);
        Map map = new HashMap<>();
        List<Food> list = new ArrayList<>();
        if(food!=null) {
            list.add(food);
            map.put("code",200);
            map.put("msg","查询成功");
            map.put("data",list);
        }
        else{
            map.put("code",201);
            map.put("msg","查询失败");
            map.put("data",null);
        }
        return map;
    }
}
