package com.example.health.service;

import com.example.health.entity.Psychological;

import java.util.List;

public interface PsychologicalService {

    int insert(Psychological psychological);

    int delete(int id);

    int edit(Psychological psychological);

    List<Psychological> selectAll();

    Psychological findByid(int id);
}
