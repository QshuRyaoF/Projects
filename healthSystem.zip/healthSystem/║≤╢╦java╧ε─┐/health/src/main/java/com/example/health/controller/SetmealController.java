
package com.example.health.controller;

import com.example.health.entity.Setmeal;
import com.example.health.service.impl.SetmealServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("setmeal")
public class SetmealController {
    @Autowired
    private SetmealServiceImpl setmealService;
    //查询全部套餐
    @RequestMapping(value = "/selectAll",method = RequestMethod.POST)
    public Map selectAll(){
        List<Setmeal> res = setmealService.findAll();
        Map map = new HashMap();
        if(res != null){
            map.put("code","200");
            map.put("msg","存在数据");
            map.put("data",res);
        }else{
            map.put("code",201);
            map.put("msg","不存在数据");
        }
        return map;
    }

    //增加套餐
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map add(Setmeal setmeal){
        int res = setmealService.add(setmeal);
        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","添加成功");
        }else{
            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }

    //根据id查套餐
    @RequestMapping(value = "/findbyId",method = RequestMethod.POST)
    public Map getforById(int id){
        Setmeal res = setmealService.findById(id);
        Map map = new HashMap();
        if(res != null){
            map.put("code","200");
            map.put("msg","存在数据");
            map.put("data",res);
        }else{
            map.put("code",201);
            map.put("msg","不存在数据");
        }
        return map;
    }

    //编辑套餐信息（根据id）
    @RequestMapping(value = "/edit",method = RequestMethod.POST)
    public Map edit(Setmeal setmeal){
        Map map = new HashMap();
        int res = setmealService.edit(setmeal);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","修改成功");
        }else{
            map.put("code","201");
            map.put("msg","修改失败");
        }
        return map;
    }

    //根据id删除套餐
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    public Map delete(int id){
        Map map = new HashMap();
        int res = setmealService.delete(id);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }

}
