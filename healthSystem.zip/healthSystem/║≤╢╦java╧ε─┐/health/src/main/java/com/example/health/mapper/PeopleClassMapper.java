package com.example.health.mapper;

import com.example.health.entity.Disease;
import com.example.health.entity.PeopleClass;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PeopleClassMapper {
    Integer add(PeopleClass peopleClass);
    List<Disease> selectAll();
    List<Disease> selectById(Integer id);
    Integer delete(Integer id);
    Integer update(PeopleClass peopleClass);
}
