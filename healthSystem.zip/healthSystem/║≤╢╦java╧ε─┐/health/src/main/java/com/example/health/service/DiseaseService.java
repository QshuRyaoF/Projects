package com.example.health.service;

import com.example.health.entity.Disease;
import com.example.health.mapper.DiseaseMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DiseaseService{

    @Autowired
    private DiseaseMapper diseaseMapper;
    public Integer add(Disease disease) {
        return diseaseMapper.add((disease));
    }

    
    public List<Disease> selectAll() {
        return diseaseMapper.selectAll();
    }

    
    public List<Disease> selectById(Integer id) {
        return diseaseMapper.selectById(id);
    }

    
    public Integer delete(Integer id) {
        return diseaseMapper.delete(id);
    }

    
    public Integer update(Disease disease) {
        return diseaseMapper.update(disease);
    }
}
