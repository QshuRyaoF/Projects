package com.example.health.entity;

/**
 *指标实体类
 * */
public class Indicator {

    private int id;//唯一标识符
    private String name;//标识名称
    private String normalReferenceValue;//正常参考值
    private String unit;//单位
    private int genderSpecific;//针对性别

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNormalReferenceValue() {
        return normalReferenceValue;
    }

    public void setNormalReferenceValue(String normalReferenceValue) {
        this.normalReferenceValue = normalReferenceValue;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getGenderSpecific() {
        return genderSpecific;
    }

    public void setGenderSpecific(int genderSpecific) {
        this.genderSpecific = genderSpecific;
    }
}
