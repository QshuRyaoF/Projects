package com.example.health.mapper;

import com.example.health.entity.Disease;
import org.springframework.aop.IntroductionAdvisor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DiseaseMapper {

    Integer add(Disease disease);
    List<Disease> selectAll();
    List<Disease> selectById(Integer id);
    Integer delete(Integer id);
    Integer update(Disease disease);

}
