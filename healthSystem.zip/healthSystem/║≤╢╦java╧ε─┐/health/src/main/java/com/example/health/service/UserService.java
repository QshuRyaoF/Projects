package com.example.health.service;

import com.example.health.entity.User;
import com.example.health.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class UserService {
    @Autowired
    private UserMapper userMapper;

    public User save(User user){
        int res = userMapper.save(user);
        return user;
    }
    public int update(User user){
        return userMapper.update(user);
    }
    public int deleteById(int id){
        return userMapper.deleteById(id);
    }
    public List<User> selectAll(){
        return userMapper.selectAll();
    }
    public User getUserInfo(int id){
        return userMapper.getUserInfo(id);
    }
    public User login(String userName,String password){return userMapper.login(userName,password);}
    public User select(String userName){return userMapper.select(userName);}
}
