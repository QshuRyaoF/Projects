package com.example.health.controller;

import com.example.health.entity.PeopleClass;
import com.example.health.service.PeopleClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/peopleclass")
public class PeopleClassController {
    @Autowired
    private PeopleClassService peopleClassService;

    @RequestMapping(value = "/add")
    public Map add(PeopleClass peopleClass) {
        Map map = new HashMap<>();
        Integer res=peopleClassService.add(peopleClass);
        if(res>=1){
            map.put("code","200");
            map.put("msg","添加成功");
        }else{
            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }

    @RequestMapping(value = "/selectAll")
    public Map selectAll() {
        Map map = new HashMap<>();
        List list=peopleClassService.selectAll();
        if(list!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/select")
    public Map selectById(Integer id) {
        Map map = new HashMap<>();
        List list=peopleClassService.selectById(id);
        if(list!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/delete")
    public Map delete(Integer id) {
        Map map = new HashMap<>();
        Integer res=peopleClassService.delete(id);
        if(res>=1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/update")
    public Map update(PeopleClass peopleClass) {
        Map map = new HashMap<>();
        Integer res=peopleClassService.update(peopleClass);
        if(res>=1){
            map.put("code","200");
            map.put("msg","修改成功");
        }else{
            map.put("code","201");
            map.put("msg","修改失败");
        }
        return map;
    }
}
