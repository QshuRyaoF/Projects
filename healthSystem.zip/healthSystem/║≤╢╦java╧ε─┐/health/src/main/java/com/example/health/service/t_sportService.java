package com.example.health.service;

import com.example.health.entity.t_sport;
import com.example.health.mapper.t_sportMapper;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;
@Service
public class t_sportService {
    @Autowired
    private t_sportMapper sportMapper;
    public t_sport save(t_sport sport){
        sportMapper.save(sport);
        return sport;
    }
    public int update(t_sport sport){
        return sportMapper.update(sport);
    }
    public int deleteById(int id){
        return  sportMapper.deleteById(id);
    }
    public List<t_sport> selectAll(){
        return sportMapper.selectAll();
    }

    public t_sport getInfo(int id){
        return sportMapper.getInfo(id);
    }
}
