package com.example.health.service;

import com.example.health.entity.Menu;
import com.example.health.entity.Role;
import com.example.health.mapper.RoleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Service
public class RoleService {
    @Autowired
    private RoleMapper roleMapper;

    //查询用户所有角色
    public List<Role> findByUserId(Integer userId) {
        return roleMapper.findByUserId(userId);
    }

    //查询所有角色
    public List<Role> findAllRoles() {
        return roleMapper.findAllRoles();
    }
//通过用户名或关键字查询角色
    public List<Role> findByName2Kd(String name, String keyword) {
        return roleMapper.findByName2Kd(name,keyword);
    }
//添加角色
    public void add(Role role) {
        roleMapper.add(role);
    }
//给角色添加权限
    public void addPermissionAndRole(Integer roleId, Integer permissionId) {
        roleMapper.addPermissionAndRole(roleId,permissionId);
    }
// 给角色添加菜单
    public void addMenuAndRole(Integer roleId, Integer menuId) {
        roleMapper.addMenuAndRole(roleId,menuId);
    }
//通过角色id查询所有与他有关的权限id
    public List<Integer> findPermissionIdByrid(Integer rId) {
        return roleMapper.findPermissionIdByrid(rId);
    }
//通过角色id查询所有与他有关的菜单id
    public List<Integer> findMenuIdByrid(Integer rId) {
        return roleMapper.findMenuIdByrid(rId);
    }
//通过角色id修改已有的角色
    public void update(Role role) {
        roleMapper.update(role);
    }
//通过觉色id删除关联的权限id
    public void deleteConnection4PermissionByrid(Integer roleId) {
        roleMapper.deleteConnection4PermissionByrid(roleId);
    }
//通过角色id删除关联的菜单id
    public void deleteConnection4MenuByrid(Integer roleId) {
        roleMapper.deleteConnection4MenuByrid(roleId);
    }
//通过角色id查找角色
    public Role findById(Integer id) {
        return roleMapper.findById(id);
    }

//通过角色id删除关联的用户
    public void deleteConnection4UserByrid(Integer id) {
        roleMapper.deleteConnection4UserByrid(id);
    }

//通过角色id删除角色
    public void deleterole(Integer id) {
        roleMapper.deleterole(id);
    }

//通过菜单id查询所有的角色
    public List<Role> findRoleBymid(Integer id) {
        return roleMapper.findRoleBymid(id);
    }

//通过角色id查询所有的菜单
    public LinkedHashSet<Menu> findMenuByRoleId(Integer roleId) {
        return roleMapper.findMenuByRoleId(roleId);
    }
}
