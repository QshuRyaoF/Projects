package com.example.health.controller;

import com.example.health.entity.Scheme;
import com.example.health.service.impl.SchemeServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("scheme")
public class SchemeController {
    @Autowired
    private SchemeServiceImpl schemeService;
    //查询所有板块
    @RequestMapping(value = "/selectAll",method = RequestMethod.POST)
    public Map selectAll(){
        List<Scheme> res = schemeService.selectAll();

        Map map = new HashMap();
        if(res != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",res);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
    //插入板块
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map add(Scheme scheme){
        int res = schemeService.add(scheme);

        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","添加成功");
        }else{
            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }
    //编辑板块
    @RequestMapping(value = "/edit",method = RequestMethod.POST)
    public Map edit(Scheme scheme){
        int res = schemeService.edit(scheme);

        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","编辑成功");
        }else{
            map.put("code","201");
            map.put("msg","编辑失败");
        }
        return map;
    }
    //删除板块
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    public Map delete(int id){
        int res = schemeService.delete(id);

        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }
    @RequestMapping(value = "/findByid",method = RequestMethod.POST)
    public Map findByid(int id){
        Scheme res= schemeService.findByid(id);

        Map map = new HashMap();
        if(res != null){
            map.put("code","200");
            map.put("msg","查询成功");
            List<Scheme> list = new ArrayList<>();
            list.add(res);
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

}
