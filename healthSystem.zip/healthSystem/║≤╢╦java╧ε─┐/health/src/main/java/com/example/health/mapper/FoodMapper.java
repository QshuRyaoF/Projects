package com.example.health.mapper;

import com.example.health.entity.Food;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FoodMapper {
    int save(Food food);
    int update(Food food);
    int deleteById(int id);
    List<Food> selectAll();
    Food getInfo(int id);
}
