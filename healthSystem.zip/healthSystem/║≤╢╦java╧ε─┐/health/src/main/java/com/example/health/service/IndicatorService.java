package com.example.health.service;

import com.example.health.entity.Disease;
import com.example.health.entity.Indicator;
import com.example.health.mapper.IndicatorMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IndicatorService {
    @Autowired
    private IndicatorMapper indicatorMapper;

    public Integer add(Indicator indicator) {
        return indicatorMapper.add(indicator);
    }


    public List<Disease> selectAll() {
        return indicatorMapper.selectAll();
    }


    public List<Disease> selectById(Integer id) {
        return indicatorMapper.selectById(id);
    }


    public Integer delete(Integer id) {
        return indicatorMapper.delete(id);
    }


    public Integer update(Indicator indicator) {
        return indicatorMapper.update(indicator);
    }
}
