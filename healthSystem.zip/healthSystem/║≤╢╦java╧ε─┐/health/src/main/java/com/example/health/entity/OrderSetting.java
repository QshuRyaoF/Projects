package com.example.health.entity;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

public class OrderSetting {
    private int id;
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date orderDate;
    private int number;
    private int reservations;

    @Override
    public String toString() {
        return "orderSetting{" +
                "id=" + id +
                ", orderDate=" + orderDate +
                ", number=" + number +
                ", reservations=" + reservations +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getReservations() {
        return reservations;
    }

    public void setReservations(int reservations) {
        this.reservations = reservations;
    }
}
