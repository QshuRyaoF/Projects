package com.example.health.entity;

/**
 * 疾病实体类
 * */
public class Disease {
    private Integer id;//唯一标识符
    private String diseaseName;//疾病名称
    private String clinic;//就诊科室
    private String medicalTreatmentPeriod;//就医期限
    private String warningLevel;//预警等级

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDiseaseName() {
        return diseaseName;
    }

    public void setDiseaseName(String diseaseName) {
        this.diseaseName = diseaseName;
    }

    public String getClinic() {
        return clinic;
    }

    public void setClinic(String clinic) {
        this.clinic = clinic;
    }

    public String getMedicalTreatmentPeriod() {
        return medicalTreatmentPeriod;
    }

    public void setMedicalTreatmentPeriod(String medicalTreatmentPeriod) {
        this.medicalTreatmentPeriod = medicalTreatmentPeriod;
    }

    public String getWarningLevel() {
        return warningLevel;
    }

    public void setWarningLevel(String warningLevel) {
        this.warningLevel = warningLevel;
    }
}
