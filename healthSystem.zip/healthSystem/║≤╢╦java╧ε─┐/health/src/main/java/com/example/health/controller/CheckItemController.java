package com.example.health.controller;

import com.example.health.entity.CheckItem;
import com.example.health.service.impl.CheckItemServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@CrossOrigin
@RestController
@RequestMapping("/CheckItem")
public class CheckItemController {
    @Autowired
    private CheckItemServiceImpl checkItemService;
    //增添item
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Map add(CheckItem checkItem){
        Map map = new HashMap();
        int res = checkItemService.add(checkItem);
        if(res >= 1){

            map.put("code","200");
            map.put("msg","添加成功");
        }else{

            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }
    //查询id号为id的GROUP对应的item
    @RequestMapping(value = "/selectByGroupId",method = RequestMethod.POST)
    public Map selectByGroupId(int id){
        Map map = new HashMap();
        List<CheckItem> res = checkItemService.selectByGroupId(id);
        if(res != null){
            map.put("code","200");
            map.put("msg","存在数据");
            map.put("data",res);
        }else {
            map.put("code","201");
            map.put("msg","不存在数据");
        }
        return map;
    }
    //删除id的Item
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    public Map deleteById(Integer id){
            int res = checkItemService.delete(id);
           Map map = new HashMap();
            if(res >= 1){
                map.put("code","200");
                map.put("msg","删除成功");

            }else{
                map.put("code","201");
                map.put("msg","删除失败");
            }
            return map;
    }
   //查询id编号的item信息
    @RequestMapping(value = "/findById",method = RequestMethod.POST)
   public Map findById(Integer id){
        CheckItem res = checkItemService.findById(id);
        Map map = new HashMap();
        if(res != null){
            map.put("code","200");
            map.put("msg","查询成功");
            List<CheckItem> list = new ArrayList<CheckItem>();
            list.add(res);
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","不存在该数据");
        }
        return map;
   }
    // 编辑item
    @RequestMapping(value = "/edit",method = RequestMethod.POST)
    public Map edit(CheckItem checkItem){
        int res = checkItemService.edit(checkItem);
        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","编辑成功");
        }else{
            map.put("code","201");
            map.put("msg","编辑失败");
        }
        return map;
    }
     //查找所有item
    @RequestMapping(value = "/selectAll",method = RequestMethod.POST)
    public Map findAll(){
        List<CheckItem> res = checkItemService.findAll();
        Map map = new HashMap();
        if(res != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",res);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
    // 将item与group绑定
    @RequestMapping(value = "/insertGroupById",method = RequestMethod.POST)
    public Map insertGroupById(int checkgroup_id,int checkitem_id) {
        int res = checkItemService.insertGroupById(checkgroup_id,checkitem_id);
        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","添加成功");
        }else{
            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }
    //将item和group解除绑定
    @RequestMapping(value = "/deleteGroupById",method = RequestMethod.POST)
    public Map deleteGroupById(int checkgroup_id,int checkitem_id) {
        int res = checkItemService.deleteGroupById(checkgroup_id,checkitem_id);
        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }
}
