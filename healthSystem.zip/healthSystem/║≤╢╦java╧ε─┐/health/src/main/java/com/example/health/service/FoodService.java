package com.example.health.service;

import com.example.health.entity.Food;
import com.example.health.entity.T_scheme;
import com.example.health.mapper.FoodMapper;
import com.example.health.mapper.T_schemeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FoodService {
    @Autowired
    private FoodMapper foodMapper;
    public Food save(Food food){
        foodMapper.save(food);
        return food;
    }

    public int update(Food food){
        return foodMapper.update(food);
    }
    public int deleteById(int id){
        return foodMapper.deleteById(id);
    }

    public List<Food> selectAll(){
        return foodMapper.selectAll();
    }
    public Food getInfo(int id){
        return foodMapper.getInfo(id);
    }
}
