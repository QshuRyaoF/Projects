package com.example.health.service;

import com.example.health.entity.Order;
import com.example.health.entity.OrderSetting;

import java.util.Date;
import java.util.List;

public interface OrderSettingService {

    List<OrderSetting> dayOrderSetting();

    int edit(Date date);

    int delete(int id);

    int save(OrderSetting orderSetting);

    OrderSetting findByid(int id);
}
