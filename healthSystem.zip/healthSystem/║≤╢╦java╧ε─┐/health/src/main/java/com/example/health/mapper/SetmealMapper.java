package com.example.health.mapper;

import com.example.health.entity.Setmeal;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SetmealMapper {
    public Integer add(Setmeal setmeal);

    //public void setSetmealAndCheckGroup(Map<String, Integer> map);

    //public Page<CheckItem> findByCondition(String queryString);

    public List<Setmeal> findAll();

    public Setmeal findById4Detail(Integer id);

    public int edit(Setmeal setmeal);

    //public List<Map> getSetmealReport();

    public int delete(int id);
}
