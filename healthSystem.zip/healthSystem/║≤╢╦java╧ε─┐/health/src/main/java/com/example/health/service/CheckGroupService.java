package com.example.health.service;

import com.example.health.entity.CheckGroup;

import java.util.List;

public interface CheckGroupService {
    public void add(CheckGroup checkGroup, Integer[] checkitemIds);
   // public PageResult findPage(QueryPageBean pageBean);
    public CheckGroup findById(Integer id);
    public int edit(CheckGroup checkGroup);
    public List<CheckGroup> findAll();
    public List<CheckGroup> setmealToGroup(Integer id);

    public int insertToSetmeal(int setmeal_id,int checkgroup_id);

    public int deleteToSetmeal(int setmeal_id,int checkgroup_id);

    public int delete(int id);
}
