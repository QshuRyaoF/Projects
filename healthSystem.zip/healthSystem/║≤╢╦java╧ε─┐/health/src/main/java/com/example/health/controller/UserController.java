package com.example.health.controller;

import com.example.health.entity.User;
import com.example.health.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin//解决跨域问题
@RestController
@RequestMapping("/testHealth")
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map insert(User user){
        User u =  userService.save(user);
        Map map = new HashMap<>();
        if(u!=null){
            map.put("code",200);
            map.put("msg","插入成功");
        }
        else{
            map.put("code",201);
            map.put("msg","插入失败");
        }
        return map;
    }

    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Map update(User user){
        Map map = new HashMap<>();
        int res=userService.update(user);
        if(res>=1){
            map.put("code",200);
            map.put("msg","修改成功");
        }
        else{
            map.put("code",201);
            map.put("msg","修改失败");
        }
        return map;
    }

    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Map delete(int id){
        Map map = new HashMap<>();
        int res=userService.deleteById(id);
        if(res>=1){
            map.put("code",200);
            map.put("msg","删除成功");
        }
        else{
            map.put("code",201);
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/selectAll",method = RequestMethod.GET)
    @ResponseBody
    public Map selectAll(){
        Map map = new HashMap<>();
        List<User> list =  userService.selectAll();
        if(list!=null) {
            map.put("code",200);
            map.put("msg","查询成功");
            map.put("data",list);
        }
        else{
            map.put("code",201);
            map.put("msg","查询失败");
            map.put("data",null);
        }
        return map;
    }

    @RequestMapping(value = "/getUserInfo",method = RequestMethod.GET)
    public Map getUserInfo(int id){
        Map map = new HashMap<>();
        User user = userService.getUserInfo(id);
        List<User> list = new ArrayList<>();
        if(user!=null) {
            list.add(user);
            map.put("code",200);
            map.put("msg","查询成功");
            map.put("data",list);
        }
        else{
            map.put("code",201);
            map.put("msg","查询失败");
            map.put("data",null);
        }
        return map;
    }

    @RequestMapping(value = "/login",method = RequestMethod.GET)
    public Map login(User user){
        Map map = new HashMap<>();
        User login = userService.login(user.getUserName(),user.getPassword());
        if(login!=null) {
            map.put("code",200);
            map.put("msg","欢迎你！"+login.getRealName());
            map.put("openId",(int)((Math.random()*9+1)*100000));
        }
        else{
            map.put("code",201);
            map.put("msg","登陆失败");
            map.put("openId",0);
        }
        return map;
    }

    @RequestMapping(value = "/select",method = RequestMethod.GET)
    public Map select(User user){
        Map map = new HashMap<>();
        User select = userService.select(user.getUserName());
        if(select!=null) {
            map.put("code",200);
            map.put("msg","密码错误！");
        }
        else{
            map.put("code",201);
            map.put("msg","用户名不存在！");
        }
        return map;
    }

}
