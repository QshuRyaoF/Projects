package com.example.health.entity;

public class Scheme {
    private int id;
    private String title;
    private String keyword;
    private String people;
    private String goal;
    private int statue;
    private  String remarks;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getPeople() {
        return people;
    }

    public void setPeople(String people) {
        this.people = people;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public int getStatue() {
        return statue;
    }

    public void setStatue(int statue) {
        this.statue = statue;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemark(String remark) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "Scheme{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", keyword='" + keyword + '\'' +
                ", people='" + people + '\'' +
                ", goal='" + goal + '\'' +
                ", statue=" + statue +
                ", remark='" + remarks + '\'' +
                '}';
    }
}
