package com.example.health.service;

import com.example.health.entity.Menu;
import com.example.health.mapper.MenuMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class MenuService {

    @Autowired
    private MenuMapper menuMapper;
    
    public List<Menu> findByRole(Integer id) {
        return menuMapper.findByRole(id);
    }

    
    public List<Map<String, Integer>> findMenus() {
        return menuMapper.findMenus();
    }

    
    public List<Menu> findByNameAndLkurl(String name, String linkUrl) {
        return menuMapper.findByNameAndLkurl(name,linkUrl);
    }

    
    public int add(Menu menu) {
        return menuMapper.add(menu);
    }

    
    public Menu findById(Integer id) {
        return menuMapper.findById(id);
    }

    
    public int edit(Menu menu) {
        return menuMapper.edit(menu);
    }

    
    public int delete(Integer id) {
        return menuMapper.delete(id);
    }

    
    public List<Menu> findByParentId(Integer id) {
        return menuMapper.findByParentId(id);
    }

    
    public int deleteConnection4RoleBymid(Integer id) {
        return menuMapper.deleteConnection4RoleBymid(id);
    }

    
    public LinkedHashSet<Menu> findAllFistMenusById(Integer id) {
        return null;
    }

    
    public List<Menu> findSecondMenusByMenuId(Integer id, Integer menuId) {
        return menuMapper.findSecondMenusByMenuId(id,menuId);
    }
}
