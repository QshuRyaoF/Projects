package com.example.health.service.impl;

import com.example.health.entity.Psychological;
import com.example.health.mapper.PsychologicalMapper;
import com.example.health.service.PsychologicalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PsychologicalServiceImpl implements PsychologicalService {
    @Autowired
    private PsychologicalMapper psychologicalMapper;
    @Override
    public int insert(Psychological psychological) {
        return psychologicalMapper.insert(psychological);
    }

    @Override
    public int delete(int id) {
        return psychologicalMapper.delete(id);
    }

    @Override
    public int edit(Psychological psychological) {
        return psychologicalMapper.edit(psychological);
    }

    @Override
    public List<Psychological> selectAll() {
        return psychologicalMapper.selectAll();
    }

    @Override
    public Psychological findByid(int id) {
        return psychologicalMapper.findByid(id);
    }
}
