package com.example.health.service;

import com.example.health.entity.Setmeal;

import java.util.List;

public interface SetmealService {
    public Integer add(Setmeal setmeal);
  //  public PageResult findPage(QueryPageBean queryPageBean);
    public List<Setmeal> findAll();

    public Setmeal findById(Integer id);

   // public List<Map> getSetmealReport();

    public int edit(Setmeal setmeal);

    public int delete(int id);
}
