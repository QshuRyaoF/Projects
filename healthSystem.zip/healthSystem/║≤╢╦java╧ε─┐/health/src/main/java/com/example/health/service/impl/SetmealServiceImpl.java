package com.example.health.service.impl;

import com.example.health.entity.Setmeal;
import com.example.health.mapper.SetmealMapper;
import com.example.health.service.SetmealService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SetmealServiceImpl implements SetmealService {
    @Autowired
    private SetmealMapper setmealMapper;
    @Override
    public  Integer add(Setmeal setmeal) {
            return setmealMapper.add(setmeal);
    }

    @Override
    public List<Setmeal> findAll() {
        return setmealMapper.findAll();
    }

    @Override
    public Setmeal findById(Integer id) {
        return setmealMapper.findById4Detail(id);
    }

    @Override
    public int edit(Setmeal setmeal) {
        return setmealMapper.edit(setmeal);
    }

    @Override
    public int delete(int id) {
        return setmealMapper.delete(id);
    }


//    @Override
//    public Setmeal findById(Integer id) {
//        return setmealMapper.findById(id);
//    }

 //   @Override
//    public List<Map> getSetmealReport() {
//        return setmealMapper.getSetmealReport();
//    }
}
