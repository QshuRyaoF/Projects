package com.example.health.service.impl;
//DairyServiceImpl块
import com.example.health.entity.Dairy;
import com.example.health.mapper.DairyMapper;
import com.example.health.service.DairyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DairyServiceIpml implements DairyService {

    @Autowired
    private DairyMapper dairyMapper;

    public int save(Dairy dairy) {
        return dairyMapper.save(dairy);
    }

    public int update(Dairy dairy) {
        return dairyMapper.update(dairy);
    }

    public int delete(int serialNum) {
        return dairyMapper.delete(serialNum);
    }

    public List<Dairy> selectAll() {
        return dairyMapper.selectAll();
    }

    public Dairy getDairyInfo(int serialNum) {
        return dairyMapper.getDairyInfo(serialNum);
    }
}
