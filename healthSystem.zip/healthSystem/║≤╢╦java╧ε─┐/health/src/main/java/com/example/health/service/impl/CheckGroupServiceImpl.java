package com.example.health.service.impl;

import com.example.health.entity.CheckGroup;
import com.example.health.mapper.CheckGroupMapper;
import com.example.health.service.CheckGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CheckGroupServiceImpl implements CheckGroupService {
    @Autowired
    private CheckGroupMapper checkGroupMapper;

    @Override
    public void add(CheckGroup checkGroup, Integer[] checkitemIds) {

    }

    @Override
    public CheckGroup findById(Integer id) {
        return checkGroupMapper.findById(id);
    }

    @Override
    public int edit(CheckGroup checkGroup) {
        return checkGroupMapper.edit(checkGroup);
    }

    @Override
    public List<CheckGroup> findAll() {
        return checkGroupMapper.findAll();
    }

    public List<CheckGroup> setmealToGroup(Integer id){
        return checkGroupMapper.setmealToGroup(id);
    }


    public int save(CheckGroup checkGroup){
        return checkGroupMapper.save(checkGroup);
    }

     public int insertToSetmeal(int setmeal_id,int checkgroup_id){
        return checkGroupMapper.insertToSetmeal(setmeal_id,checkgroup_id);
    }

    public int deleteToSetmeal(int setmeal_id,int checkgroup_id){
        return checkGroupMapper.deleteToSetmeal(setmeal_id,checkgroup_id);
    }

    public int delete(int id){
        return checkGroupMapper.delete(id);
    }
}
