package com.example.health.mapper;

import com.example.health.entity.User;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface UserMapper {
    //    新增用户
//    @param user
//    @return
    int save(User user);
    //    修改用户
//    @param user
//    @return
    int update(User user);
    //    删除用户（根据id）
//    @param user
//    @return
    int deleteById(int id);
    //    查询所有
//    @param user
//    @return
    List<User> selectAll();
    //    通过id查询用户详情
//    @param user
//    @return
    User getUserInfo(int id);
    //    登录
//    @param username
//    @param password
//    @return
    User login(String userName,String password);
    User select(String userName);
}
