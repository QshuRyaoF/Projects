package com.example.health.mapper;

import com.example.health.entity.CheckItem;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CheckItemMapper {
    public int add(CheckItem checkItem);
//
//    public long selectCountByCheckItemId(Integer checkItemId);
    //删除item
    public int deleteById(Integer id);
    //查询id编号的item信息
    public CheckItem findById(Integer id);
    //编辑item
    public int edit(CheckItem checkItem);
    //查找所有item
    public List<CheckItem> findAll();
//    public List<Integer> findCheckItemIdsByCheckGroupId(Integer checkgroupId);
   //查询group_id绑定的item
    public List<CheckItem> selectByGroupId(int id);
    //将item与group绑定
    public int insertGroupById(int checkgroup_id , int checkitem_id);
    public int deleteGroupById(int checkgroup_id , int checkitem_id);
}
