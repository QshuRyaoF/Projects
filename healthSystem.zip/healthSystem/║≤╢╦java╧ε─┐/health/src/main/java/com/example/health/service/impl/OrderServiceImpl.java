package com.example.health.service.impl;

import com.example.health.entity.Order;
import com.example.health.mapper.OrderMapper;
import com.example.health.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderMapper orderMapper;
    public List<Order> selectAll(){
        return orderMapper.selectAll();
    }

    public  int update(Order order){
        return orderMapper.update(order);
    }

    public int save(Order order){
        return orderMapper.save(order);
    }

    public int delete(Order order){
        return orderMapper.delete(order);
    }

    public int submit(Order order){
        return orderMapper.submit(order);
    }

    public int max(){
        return orderMapper.max();
    }

   public List<Order> dayOrder(Date date){
        return orderMapper.dayOrder(date);
   }
    public  Order findByID(int id){
        return orderMapper.findByID(id);
    }
}
