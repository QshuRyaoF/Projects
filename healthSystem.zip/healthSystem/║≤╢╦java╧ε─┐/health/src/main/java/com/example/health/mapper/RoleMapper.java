package com.example.health.mapper;

import com.example.health.entity.Menu;
import com.example.health.entity.Role;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Repository
public interface RoleMapper {

    /**
     * 查询用户所有角色
     * @param userId
     * @return
     * */
    List<Role> findByUserId(Integer userId);

    /**
     * 查询所有角色
     * @param
     * @return
     * */
    List<Role> findAllRoles();

    /**
     * 通过用户名或关键字查询角色
     * @param name
     * @param keyword
     * @return
     * */
    List<Role> findByName2Kd(String name,String keyword);

    /**
     * 添加角色
     * @param role
     * @return
     * */
    void add(Role role);

    /**
     * 给角色添加权限
     * @param roleId
     * @param permissionId
     * @return
     * */
    void addPermissionAndRole(Integer roleId,Integer permissionId);

    /**
     * 给角色添加菜单
     * @param roleId
     * @param menuId
     * @return
     * */
    void addMenuAndRole(Integer roleId, Integer menuId);

    /**
     * 通过角色id查询所有与他有关的权限id
     * @param rId
     * @return
     * */
    List<Integer> findPermissionIdByrid(Integer rId);

    /**
     * 通过角色id查询所有与他有关的菜单id
     * @param rId
     * @return
     * */
    List<Integer> findMenuIdByrid(Integer rId);

    /**
     * 通过角色id修改已有的角色
     * @param role
     * @return
     * */
    void update(Role role);

    /**
     * 通过觉色id删除关联的权限id
     * @param roleId
     * @return
     * */
    void deleteConnection4PermissionByrid(Integer roleId);

    /**
     * 通过角色id删除关联的菜单id
     * @param roleId
     * @return
     * */
    void deleteConnection4MenuByrid(Integer roleId);

    /**
     * 通过角色id查找角色
     * @param id
     * @return
     * */
    Role findById(Integer id);

    /**
     * 通过角色id删除关联的用户
     * @param id
     * @return
     * */
    void deleteConnection4UserByrid(Integer id);

    /**
     * 通过角色id删除角色
     * @param id
     * @return
     * */
    void deleterole(Integer id);

    /**
     * 通过菜单id查询所有的角色
     * @param  id
     * @return
     * */
    List<Role> findRoleBymid(Integer id);

    /**
     * 通过角色id查询所有的菜单
     * @param roleId
     * @return
     * */
    LinkedHashSet<Menu> findMenuByRoleId(Integer roleId);

}
