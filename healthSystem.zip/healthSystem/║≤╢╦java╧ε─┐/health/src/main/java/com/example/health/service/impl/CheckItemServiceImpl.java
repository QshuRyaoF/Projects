package com.example.health.service.impl;

import com.example.health.entity.CheckItem;
import com.example.health.mapper.CheckItemMapper;
import com.example.health.service.CheckItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CheckItemServiceImpl implements CheckItemService {
    @Autowired
    private CheckItemMapper checkItemMapper;
    @Override
    public int add(CheckItem checkItem) {
        return checkItemMapper.add(checkItem);
    }

    @Override
    public int delete(Integer id) {
        return checkItemMapper.deleteById(id);
    }

    @Override
    public CheckItem findById(Integer id) {
        return checkItemMapper.findById(id);
    }

    @Override
    public int edit(CheckItem checkItem) {
        return checkItemMapper.edit(checkItem);
    }

    @Override
    public List<CheckItem> findAll() {
        return checkItemMapper.findAll();
    }

    @Override
    public List<Integer> findCheckItemIdsByCheckGroupId(Integer checkgroupId) {
        return null;
    }

    public List<CheckItem> selectByGroupId(int id){
        return checkItemMapper.selectByGroupId(id);
    }

    @Override
    public int insertGroupById(int checkgroup_id, int checkitem_id) {
        return checkItemMapper.insertGroupById(checkgroup_id,checkitem_id);
    }

    public int deleteGroupById(int checkgroup_id , int checkitem_id){
        return  checkItemMapper.deleteGroupById(checkgroup_id,checkitem_id);
    }


}
