package com.example.health.controller;

import com.example.health.entity.Order;
import com.example.health.service.impl.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@CrossOrigin
@RestController
@RequestMapping("/Order")
public class OrderController {
    @Autowired
    private OrderServiceImpl orderService;

    //查询所有预约1
    @RequestMapping(value = "/selectAll",method = RequestMethod.POST)
    public Map selectAll(){
        List<Order> res = orderService.selectAll();
        Map map = new HashMap<>();
        if(res != null){

            map.put("code","200");
            map.put("msg","存在数据");
            map.put("data",res);
        }else {
            map.put("code","201");
            map.put("msg","不存在数据");
        }
        return map;
    }

    //更新预约信息（根据id）
    @RequestMapping(value = "/edit",method = RequestMethod.POST)
    public Map update(Order order){
        int res= orderService.update(order);
        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","更新成功");
        }else{
            map.put("code","201");
            map.put("msg","更新失败");
        }
        return map;
    }

    //保存预约1
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map save(Order order){
        order.setId(orderService.max()+1);
        int cnt = orderService.save(order);
        int res =  orderService.update(order);
        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","预约成功");
        }else{
            map.put("code","201");
            map.put("msg","预约失败");
        }
        return map;
    }

    //删除预约1
    @RequestMapping(value = "/deleteById",method = RequestMethod.POST)
    public Map delete(Order order){
        int res = orderService.delete(order);
        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }

    //提交报告1
    @RequestMapping(value = "/submit",method = RequestMethod.POST)
    public Map submit(Order order){
        int res = orderService.submit(order);
        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","提交成功");
        }else{
            map.put("code","201");
            map.put("msg","提交失败");
        }
        return map;
    }

    //查询每日的预约数量1
    @RequestMapping(value = "/mouthOrder",method = RequestMethod.POST)
    public Map mouthOrder(){
        List<Order> res = orderService.selectAll();
        Map cnt = new HashMap();
        Map <Date,Integer> map = new HashMap<Date,Integer>();
        for(Order order : res){
            boolean flag=map.containsKey(order.getOrderDate());
            if(!flag){
                map.put(order.getOrderDate(),1);
            }else{
                int cnt1 = (int) map.get(order.getOrderDate());
                map.put(order.getOrderDate(),cnt1 + 1);
            }
        }
        if(res == null){
            cnt.put("code","201");
            cnt.put("msg","查询失败");
            return cnt;
        }
        cnt.put("code","200");
        cnt.put("msg","查询成功");
        List<Map> list = new ArrayList<Map>();
        for(Date date : map.keySet()){
            Map map1 = new HashMap();
            map1.put("Date",date);
            map1.put("count",map.get(date));
            list.add(map1);
        }

        cnt.put("data",list);
      //  List<Map> ans = new List<Map>();
        return cnt;
    }
    //查询某日的所有预约1
    @RequestMapping(value = "/dayOrder",method = RequestMethod.POST)
    public Map dayOrder(Date  orderDate){
        Map map = new HashMap();
       // Date date1 = new java.sql.Date(date.getOrderDate());
      //  date.setOrderDate();
        List<Order> res = orderService.dayOrder(orderDate);
        if(res != null){
            map.put("code","300");
            map.put("msg","存在预约");
            map.put("data",res);
        }else{
            map.put("code","301");
            map.put("msg","不存在预约");
        }
        return map;
    }
    @RequestMapping(value = "/findById",method = RequestMethod.POST)
    public Map findById(int id) {
        Order res = orderService.findByID(id);
        Map map = new HashMap();
        if(res != null){
            List<Order> list = new ArrayList<Order>();
            list.add(res);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
}
