package com.example.health.service;

import com.example.health.entity.Order;

import java.util.Date;
import java.util.List;


public interface OrderService {
    List<Order> selectAll();

    int update(Order order);

    int save(Order order);

    int delete(Order order);

    int submit(Order order);

    int max();

    List<Order> dayOrder(Date date);
    Order findByID(int ID);

}
