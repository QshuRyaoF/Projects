package com.example.health.controller;


import com.example.health.entity.OrderSetting;
import com.example.health.service.impl.OrderSettingServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@CrossOrigin
@RestController
@RequestMapping("ordersetting")
public class OrderSettingController {
    @Autowired
    private OrderSettingServiceImpl orderSettingService;
    //得到每日的预约设置
    @RequestMapping(value = "/dayOrderSetting",method = RequestMethod.POST)
    public Map dayOrderSetting(){
        Map map = new HashMap();
        List<OrderSetting> res = orderSettingService.dayOrderSetting();
        if(res != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",res);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
    //根据日期编辑当日预约设置
    @RequestMapping(value = "/edit",method = RequestMethod.POST)
    public Map edit(Date orderDate){
        int res = orderSettingService.edit(orderDate);

        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","修改成功");
        }else{
            map.put("code","201");
            map.put("msg","修改失败");
        }
        return map;
    }
    //添加预约设置
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map save(OrderSetting orderSetting){
        int res = orderSettingService.save(orderSetting);

        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","设置成功");
        }else{
            map.put("code","201");
            map.put("msg","设置失败");
        }
        return map;
    }
    //删除预约设置
    @RequestMapping(value = "/deleteById",method = RequestMethod.POST)
    public Map delete(int id){
        int res = orderSettingService.delete(id);

        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/findByid",method = RequestMethod.POST)
    public Map findByid(int id){
        OrderSetting res = orderSettingService.findByid(id);
        Map map = new HashMap();
        if(res != null){
            map.put("code","200");
            map.put("msg","删除成功");
            List<OrderSetting> list = new ArrayList<>();
            list.add(res);
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }
}
