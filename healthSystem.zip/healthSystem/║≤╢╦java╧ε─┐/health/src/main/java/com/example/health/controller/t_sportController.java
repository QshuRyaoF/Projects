package com.example.health.controller;

import com.example.health.entity.User;
import com.example.health.entity.t_sport;
import com.example.health.service.t_sportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin//解决跨域问题
@RestController
@RequestMapping("/testSport")
public class t_sportController {

    @Autowired
    private t_sportService sportService;

    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map insert(t_sport sport){
        t_sport s =  sportService.save(sport);
        Map map = new HashMap<>();
        if(s!=null){
            map.put("code",200);
            map.put("msg","插入成功");
        }
        else{
            map.put("code",201);
            map.put("msg","插入失败");
        }
        return map;
    }

    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Map update(t_sport sport){
        int res=sportService.update(sport);
        Map map = new HashMap<>();
        if(res>=1){
            map.put("code",200);
            map.put("msg","更新成功");
        }
        else{
            map.put("code",201);
            map.put("msg","更新失败");
        }
        return map;
    }

    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Map delete(int id){
        int res=sportService.deleteById(id);
        Map map = new HashMap<>();
        if(res>=1){
            map.put("code",200);
            map.put("msg","删除成功");
        }
        else{
            map.put("code",201);
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/selectAll",method = RequestMethod.GET)
    @ResponseBody
    public Map selectAll(){
        List<t_sport> list = sportService.selectAll();
        Map map = new HashMap<>();
        if(list!=null) {
            map.put("code",200);
            map.put("msg","查询成功");
            map.put("data",list);
        }
        else{
            map.put("code",201);
            map.put("msg","查询失败");
            map.put("data",null);
        }
        return map;
    }

    @RequestMapping(value = "/getInfo",method = RequestMethod.GET)
    public Map getInfo(int id){
        t_sport sport = sportService.getInfo(id);
        Map map = new HashMap<>();
        List<t_sport> list = new ArrayList<>();
        if(sport!=null) {
            list.add(sport);
            map.put("code",200);
            map.put("msg","查询成功");
            map.put("data",list);
        }
        else{
            map.put("code",201);
            map.put("msg","查询失败");
            map.put("data",null);
        }
        return map;
    }


}
