package com.example.health.entity;

import java.util.Date;

public class Psychological {
    private int id;//唯一表示名
    private String code;//档案号
    private String name;//姓名
    private Date date;//心理评测日期
    private  String   somatization;//躯体化
    private String Obsessive;//强迫症化
    private String i_sensitivity;//人际关系敏感
    private String hesitate;//犹豫
    private String anxiety;//焦虑
    private String hositile;//敌对
    private String terrorist;//恐怖
    private String paranoid;//偏执
    private String Mental;//精神病性

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getSomatization() {
        return somatization;
    }

    public void setSomatization(String somatization) {
        this.somatization = somatization;
    }

    public String getObsessive() {
        return Obsessive;
    }

    public void setObsessive(String obsessive) {
        Obsessive = obsessive;
    }

    public String getI_sensitivity() {
        return i_sensitivity;
    }

    public void setI_sensitivity(String i_sensitivity) {
        this.i_sensitivity = i_sensitivity;
    }

    public String getHesitate() {
        return hesitate;
    }

    public void setHesitate(String hesitate) {
        this.hesitate = hesitate;
    }

    public String getAnxiety() {
        return anxiety;
    }

    public void setAnxiety(String anxiety) {
        this.anxiety = anxiety;
    }

    public String getHositile() {
        return hositile;
    }

    public void setHositile(String hositile) {
        this.hositile = hositile;
    }

    public String getTerrorist() {
        return terrorist;
    }

    public void setTerrorist(String terrorist) {
        this.terrorist = terrorist;
    }

    public String getParanoid() {
        return paranoid;
    }

    public void setParanoid(String paranoid) {
        this.paranoid = paranoid;
    }

    public String getMental() {
        return Mental;
    }

    public void setMental(String mental) {
        Mental = mental;
    }
}
