package com.example.health.mapper;

import com.example.health.entity.Order;
import com.example.health.entity.OrderSetting;

import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface OrderSettingMapper {

    //每日预约设置
    List<OrderSetting> dayOrderSetting();
    //根据日期修改预约总数
    int edit(Date date);

    int delete(int id);

    int save(OrderSetting orderSetting);

    OrderSetting findByid(int id);
}
