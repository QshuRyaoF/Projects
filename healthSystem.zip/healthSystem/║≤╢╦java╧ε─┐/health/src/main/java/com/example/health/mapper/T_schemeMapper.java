package com.example.health.mapper;

import com.example.health.entity.T_scheme;

import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface T_schemeMapper {
    int save(T_scheme scheme);
    int update(T_scheme scheme);
    int deleteById(int id);
    List<T_scheme> selectAll();
    List<T_scheme> getInfo(T_scheme s);
}
