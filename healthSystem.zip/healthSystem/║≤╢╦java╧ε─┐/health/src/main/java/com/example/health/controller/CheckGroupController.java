package com.example.health.controller;

import com.example.health.entity.CheckGroup;
import com.example.health.service.impl.CheckGroupServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@CrossOrigin
@RestController
@RequestMapping("CheckGroup")
public class CheckGroupController {
    @Autowired
    private CheckGroupServiceImpl checkGroupService;
    //返回套餐setmael对应id的Group
    @RequestMapping(value = "/selectBysetmealId",method = RequestMethod.POST)
    public Map selectBysetmealId(int setmeal_id){
        Map map = new HashMap();
        List<CheckGroup> res = checkGroupService.setmealToGroup(setmeal_id);
        if(res != null){
            map.put("code","200");
            map.put("msg","存在数据");
            map.put("data",res);
        }else {
            map.put("code","201");
            map.put("msg","不存在数据");
        }
        return map;
    }
    //返回所有的组
    @RequestMapping(value = "/selectAll",method = RequestMethod.POST)
    public Map findAll(){
        List<CheckGroup> res = checkGroupService.findAll();
        Map map = new HashMap();
        if(res != null){
            map.put("code","200");
            map.put("msg","数据存在");
            map.put("data",res);
        }else{
            map.put("code","201");
            map.put("msg","数据不存在");
        }
        return map;
    }
    //新增checkgroup
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map save(CheckGroup checkGroup){
        int res = checkGroupService.save(checkGroup);
        Map map = new HashMap();
        if(res >= 1){
            map.put("code","200");
            map.put("msg","保存成功");
        }else{
            map.put("code","201");
            map.put("msg","保存失败");
        }
        return map;
    }
    //根据Id查询组
    @RequestMapping(value = "/findById",method = RequestMethod.POST)
    public Map findById(Integer id){
        Map map = new HashMap();
        CheckGroup res = checkGroupService.findById(id);
        List<CheckGroup> list = new ArrayList<CheckGroup>();
        if(res != null){
            list.add(res);
            map.put("code","200");
            map.put("msg","存在数据");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","不存在数据");
        }
        return map;
    }
    //绑定setmeal和checkgroup
    @RequestMapping(value = "/insertToSetmeal",method = RequestMethod.POST)
    public Map insertToSetmeal(int setmeal_id ,int checkgroup_id){
        int res = checkGroupService.insertToSetmeal(setmeal_id,checkgroup_id);
        Map cnt = new HashMap();
        if(res >= 1){
            cnt.put("code","200");
            cnt.put("msg","添加成功");
        }else{
            cnt.put("code","201");
            cnt.put("msg","添加失败");
        }
        return cnt;
    }
    //解除setmeal和checkgroup绑定
    @RequestMapping(value = "/deleteToSetmeal",method = RequestMethod.POST)
    public Map deleteToSetmeal(int setmeal_id ,int checkgroup_id){
        int res = checkGroupService.deleteToSetmeal(setmeal_id,checkgroup_id);
        Map cnt = new HashMap();
        if(res >= 1){
            cnt.put("code","200");
            cnt.put("msg","删除成功");
        }else{
            cnt.put("code","201");
            cnt.put("msg","删除失败");
        }
        return cnt;
    }
    //编辑checkgroup
    @RequestMapping(value = "/edit",method = RequestMethod.POST)
    public Map edit(CheckGroup checkGroup){
        Map map = new HashMap();
        int res = checkGroupService.edit(checkGroup);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","修改成功");
        }else{
            map.put("code","201");
            map.put("msg","修改失败");
        }
        return map;
    }

    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    public Map delete(int id){
        Map map = new HashMap();
        int res = checkGroupService.delete(id);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }


}
