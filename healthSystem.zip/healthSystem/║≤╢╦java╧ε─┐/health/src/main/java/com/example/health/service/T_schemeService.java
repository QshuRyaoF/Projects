package com.example.health.service;

import com.example.health.entity.T_scheme;
import com.example.health.mapper.T_schemeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class T_schemeService {
    @Autowired
    private T_schemeMapper schemeMapper;
    public T_scheme save(T_scheme scheme){
        schemeMapper.save(scheme);
        return scheme;
    }

    public int update(T_scheme scheme){
        return schemeMapper.update(scheme);
    }
    public int deleteById(int id){
        return schemeMapper.deleteById(id);
    }

    public List<T_scheme> selectAll(){
        return schemeMapper.selectAll();
    }
    public List<T_scheme> getInfo(T_scheme s){
        return schemeMapper.getInfo(s);
    }
}
