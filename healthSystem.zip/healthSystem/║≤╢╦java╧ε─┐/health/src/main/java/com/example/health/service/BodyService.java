package com.example.health.service;

import com.example.health.entity.Body;

import java.util.List;

public interface BodyService {
    int save(Body body);

    int update(Body body);

    int delete(int fileNo);

    List<Body> selectAll();

    Body getBodyInfo(int fileNo);
}
