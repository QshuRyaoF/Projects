package com.example.health.service.impl;

import com.example.health.entity.Order;
import com.example.health.entity.OrderSetting;
import com.example.health.mapper.OrderSettingMapper;
import com.example.health.service.OrderSettingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class OrderSettingServiceImpl implements OrderSettingService {
    @Autowired
    private OrderSettingMapper orderSettingMapper;

   public List<OrderSetting> dayOrderSetting(){
        return orderSettingMapper.dayOrderSetting();
    }

    public int edit(Date date){
       return orderSettingMapper.edit(date);
    }

    public int save(OrderSetting orderSetting){
       return orderSettingMapper.save(orderSetting);
    }

    public int delete(int id){
       return orderSettingMapper.delete(id);
    }

    public OrderSetting findByid(int id){
       return orderSettingMapper.findByid(id);
    }
}
