package com.example.health.controller;

import com.example.health.entity.Body;
import com.example.health.service.impl.BodyServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@CrossOrigin
@Service
@RestController
@RequestMapping("testBody")
public class BodyController {
    @Autowired
    BodyController bodyController;
    @Autowired
    BodyServiceImpl bodyService;
//    插入新数据
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Map insert(Body body){
        Map map = new HashMap();
        int res = bodyService.save(body);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","chenggong");
        }
        else{
            map.put("code","201");
            map.put("msg","shibai");
        }
        return map;
    }
//    按照序号更新数据
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Map update(Body body){
        Map map = new HashMap();
        int res = bodyService.update(body);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","chenggong");
        }
        else{
            map.put("code","201");
            map.put("msg","shibai");
        }
        return map;
    }
//    按照序号删除数据
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Map delete(int fileNo){
        Map map = new HashMap();
        int res = bodyService.delete(fileNo);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","chenggong");
        }
        else{
            map.put("code","201");
            map.put("msg","shibai");
        }
        return map;
    }
//    查找全部数据
    @RequestMapping(value = "/selectAll",method = RequestMethod.POST)
    public Map selectAll(){
        Map map = new HashMap();
        List<Body> res = bodyService.selectAll();
        if(res != null){
            map.put("data",res);
            map.put("code","200");
            map.put("msg","chenggong");
        }
        else{
            map.put("code","201");
            map.put("msg","shibai");
        }
        return map;
    }
//    按照序号 单个查找数据
    @RequestMapping(value = "/getBodyInfo",method = RequestMethod.GET)
    public Map getBodyInfo(int fileNo){
        Map map = new HashMap();

        Body body = bodyService.getBodyInfo(fileNo);
        List<Body> res = new ArrayList<Body>();
        if(body != null){
            res.add(body);
            map.put("data",res);
            map.put("code","200");
            map.put("msg","chenggong");
        }
        else{
            map.put("data",null);
            map.put("code","201");
            map.put("msg","shibai");
        }
        return map;
    }
}
