package com.example.health.controller;

import com.example.health.entity.Permission;
import com.example.health.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@CrossOrigin
@RestController
@RequestMapping("/permission")
public class PermissionController {

    @Autowired
    private PermissionService permissionService;

    @RequestMapping(value = "/getByRid")
    public Map findByRoleId(Integer rid) {
        Map map = new HashMap<>();
        List list=permissionService.findByRoleId(rid);
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/add")
    public Map add(Permission permission) {
        Map map = new HashMap<>();
        int res=permissionService.add(permission);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","添加成功");
        }else{
            map.put("code","201");
            map.put("msg","添加失败");
        }
        return map;
    }

    @RequestMapping(value = "/findByPmName2Kwd")
    public Map findByPmName2KeyWord(String name, String keyword) {
        Map map = new HashMap<>();
        Permission permission=permissionService.findByPmName2KeyWord(name,keyword);
        if(permission!=null){
            List list=new ArrayList<>();
            list.add(permission);
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/edit")
    public Map edit(Permission permission) {
        Map map = new HashMap<>();
        int res=permissionService.edit(permission);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","修改成功");
        }else{
            map.put("code","201");
            map.put("msg","修改失败");
        }
        return map;
    }

    @RequestMapping(value = "/findRolesByPmId")
    public Map findRolesByPmId(int id) {
        Map map = new HashMap<>();
        List list=permissionService.findRolesByPmId(id);
        if(list!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }

    @RequestMapping(value = "/deleteConnection4roleByPmId")
    public Map deleteConnection4roleByPmId(int id) {
        Map map = new HashMap<>();
        int res=permissionService.deleteConnection4roleByPmId(id);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/delete")
    public Map deleteByPmId(int id) {
        Map map = new HashMap<>();
        int res=permissionService.deleteByPmId(id);
        if(res >= 1){
            map.put("code","200");
            map.put("msg","删除成功");
        }else{
            map.put("code","201");
            map.put("msg","删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/getAll")
    public Map findAllPermission() {
        Map map=new HashMap<>();
        List list=permissionService.findAllPermission();
        if(list != null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
    @RequestMapping(value = "/findById")
    public Map findById(Integer id){
        Map map=new HashMap<>();
        List<Permission> list=permissionService.findById(id);
        if(list!=null){
            map.put("code","200");
            map.put("msg","查询成功");
            map.put("data",list);
        }else{
            map.put("code","201");
            map.put("msg","查询失败");
        }
        return map;
    }
}
