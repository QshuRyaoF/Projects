package com.dao;
//数据库访问层

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import com.model.userInfo;
import com.mysql.jdbc.Connection;
import com.util.DbUtil;



public class dioUserInfo {
	Connection con = new DbUtil().getConn(); 
//	登录操作
	public userInfo Login(userInfo users) {
	
//		加载驱动
		try {
//			创建sql语句
			String sql = "select * from persons where ID = ? and passwd=?";
//			执行sql命令对象
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, users.getID());
			preparedStatement.setString(2, users.getPasswd());
//			返回受影响的行数
			ResultSet res = preparedStatement.executeQuery();
//			取出当前的用户名
			if(res.next()) {
				users.setName(res.getString("Name"));
				users.setManage(res.getInt("Manage"));
			}
//			关闭资源
			try {
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return users;//返回
	}
//	添加用户
	public void Adduser(userInfo user){
		String sql = "insert into persons values ("+user.getID()+",'"+user.getName()+"',"+user.getAge()+",'"+user.getSex()+"','"
					+user.getPasswd()+"',"+user.getManage()+","+user.getSalary()+",'"+user.getFulltime()+"',"+user.getAbsenteeism()
					+","+user.getAmountofRewards()+","+user.getAmountofPenalties()+")";
//		String sql="insert into persons values(2021000008,'李四',20,'男','123456',0,1000,'是',0,0,0)";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			boolean resultSet = preparedStatement.execute(sql);
			if(resultSet==true) {
				System.out.println("Add Successful");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
//查询该用户是否存在
		public boolean search(int ID) {
			boolean ans=false;
			try {
//				创建sql语句
				String sql="select * from persons where id =?;";
//				执行sql命令对象
				PreparedStatement preparedStatement =con.prepareStatement(sql);
				preparedStatement.setInt(1, ID);
//				返回受影响的行数
				ResultSet res=preparedStatement.executeQuery();
//				取出当前的用户名
				if(res.next()) {
					if(!res.getString("Name").equals("")){
						ans=true;
					}
				}
//				关闭资源
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			return ans;
		}
//	查询所有用户个人信息
	public List<userInfo> ShowUserInfo(String name){
		List<userInfo> list = new ArrayList<userInfo>();
		String sql = "select * from persons ";
		if(!name.isEmpty()) {
			sql+="where Name like '%"+name+"%'";
		}
		try {
			PreparedStatement ps = (PreparedStatement)con.prepareStatement(sql);
//			获取结果
			ResultSet res = ps.executeQuery();
//			将返回的数据绑定到集合
			while(res.next()) {
				userInfo us = new userInfo();
				us.setID(res.getInt("ID"));
				us.setName(res.getString("Name"));
				us.setAge(res.getInt("Age"));
				us.setSex(res.getString("sex"));
				us.setPasswd(res.getString("passwd"));
				us.setManage(res.getInt("Manage"));
				us.setSalary(res.getDouble("Salary"));
				us.setFulltime(res.getString("Fulltime"));
				us.setAbsenteeism(res.getInt("Absenteeism"));
				us.setAmountofRewards(res.getDouble("AmountofRewards"));
				us.setAmountofPenalties(res.getDouble("AmountofPenalties"));
//				将数据填充到集合
				list.add(us);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
//	 修改用户信息
		public void Amend(String id, String type, String s) {
			if (type.compareTo("姓名") == 0) {
				type = "Name";
			}
			if (type.compareTo("年龄") == 0) {
				type = "Age";
			}
			if (type.compareTo("性别") == 0) {
				type = "sex";
			}
			if (type.compareTo("密码") == 0)
				type = "passwd";
			if (type.compareTo("全勤") == 0)
				type = "Fulltime";
			if (type.compareTo("缺勤次数") == 0)
				type = "Absenteeism";
			if (type.compareTo("基本工资") == 0)
				type = "Salary";
			try {
				// 声明sql语句
				String sql = "update persons set " + type + "='" + s + "' where ID=" + id;
				// 执行sql命令对象
				con.prepareStatement(sql).execute();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				// 关闭资源
				if (con == null)
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
		}
/*		
 * 应缴税额率计算应纳税所得额 = 税前工资收入金额 － 五险一金(个人缴纳部分) － 专项扣除 － 起征点(5000元)
 * 应纳税额 = 应纳税所得额 x 税率 － 速算扣除数
*/
		public Double check(Double number) {
//			Double taxDouble = null;
			if(number <= 5000&&number>0) {return number*0.05;}
			else if(number > 5000&&number<=10000) {return (number-5000)*0.10+5000*0.05-250;}
			else if(number > 10000&&number<=30000) {return (number-10000)*0.20+5000*0.10+5000*0.05-1250;}
			else if(number > 30000&&number<=50000) {return (number-30000)*0.30+20000*0.20+5000*0.10+5000*0.05-4250;}
			else if(number > 50000){return (number-50000)*0.35+20000*0.30+20000*0.20+5000*0.10+5000*0.05-4250;}
			else return 0.0;
		}
		
//		 删除用户逻辑
		public Boolean deleteuser(int id,userInfo user) {
			if(user.getID()==id) {
				JOptionPane.showMessageDialog(null, "不可以删除自己");
				return false;
			}
			else {
				String sql = "delete from persons where ID=" + id;
				try {
					// 执行sql语句，其中.exrcute方法才是执行，前面的prepareStatement方法只是将sql语句变成命令，而且在执行insert和update语句时执行命令
					// 应该用excute(),而不是excuteQuery(),这只是我的经验，我并不知道为什么要这样
					con.prepareStatement(sql).execute();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return true;
			}
			
		}
//		修改密码逻辑
		public void changePwd(int id,int pwd) {
			//声明sql语句
			String sql = "update persons set passwd=" +pwd+ " where id="+id;
			try {
				//执行sql语句，其中.exrcute方法才是执行，前面的prepareStatement方法只是将sql语句变成命令，而且在执行insert和update语句时执行命令
				//应该用excute(),而不是excuteQuery(),这只是我的经验，我并不知道为什么要这样
//				System.out.println("1");
				con.prepareStatement(sql).execute();
				JOptionPane.showMessageDialog(null, "修改成功！");
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


}


