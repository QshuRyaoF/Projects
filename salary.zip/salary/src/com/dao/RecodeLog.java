package com.dao;
/*
 * 操作日志
 * */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;

//日志
public class RecodeLog {
	public void setLog(String oprate) {
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
		Date dateA = new Date(System.currentTimeMillis());
		String data = formatter.format(dateA);
		//日志系统
		BufferedWriter bw = null;
        try {
			bw = new BufferedWriter(new FileWriter(new File("E:\\eclipseCode\\salary\\src\\FileLog\\Log.txt"),true));
			bw.write("日期: " + data + "  操作" + ": " + oprate + "\n");
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(bw!=null) {
				try {
					bw.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}
			}
		}		
	}
	
}


