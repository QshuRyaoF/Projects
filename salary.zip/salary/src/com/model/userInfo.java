package com.model;
//用户信息实体类
public class userInfo {
	private int ID;
	private String Name;
	private int Age;
	private String sex;//性别
	private String Fulltime;
	private int Taxes;
	private double Salary;
	private double AmountofRewards;
	private double AmountofPenalties;
	private String passwd;
	private int Manage;
	private int Absenteeism;
	
	
	public int getAbsenteeism() {
		return Absenteeism;
	}
	public void setAbsenteeism(int absenteeism) {
		Absenteeism = absenteeism;
	}
	public int getManage() {
		return Manage;
	}
	public void setManage(int d) {
		Manage = d;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getFulltime() {
		return Fulltime;
	}
	public void setFulltime(String fulltime) {
		Fulltime = fulltime;
	}
	public int getTaxes() {
		return Taxes;
	}
	public void setTaxes(int taxes) {
		Taxes = taxes;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double d) {
		Salary = d;
	}
	public double getAmountofRewards() {
		return AmountofRewards;
	}
	public void setAmountofRewards(double d) {
		AmountofRewards = d;
	}
	public double getAmountofPenalties() {
		return AmountofPenalties;
	}
	public void setAmountofPenalties(double d) {
		AmountofPenalties = d;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int i) {
		Age = i;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	
	
}
