package com.util;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

//连接数据类
public class DbUtil {
//	数据库的连接字符串
	private String dbUrl="jdbc:mysql://localhost:3306/salary";
//	数据库登录用户名和密码
	private String dbName = "root";
	private String dbPwd = "314159";
//	创建驱动
	private String jdbcName = "com.mysql.jdbc.Driver";
	
//	打开数据库连接方法
	public Connection getConn() {
		Connection connection = null;
		try {
//	加载jdbc驱动
			Class.forName(jdbcName);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
//	连接mysql数据库
			connection = (Connection) DriverManager.getConnection(dbUrl,dbName,dbPwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}
//	关闭资源
	public void CloseConn(Connection connection) {
		if(connection!=null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
//	public static void main(String[] args) throws SQLException{
//		DbUtil util =  new DbUtil();
//		util.getConn();
//		System.out.println("连接数据库成功");
//		util.CloseConn(util.getConn());
//		System.out.println("关闭数据库");
//	}
	
}
