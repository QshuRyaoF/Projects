package com.view;
/*
 * 管理员查询员工信息界面
 * */
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.dao.dioUserInfo;
import com.model.userInfo;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class maPsnalimfor extends JFrame {

	private JPanel contentPane;
	private JTable table = new JTable();
	private JTextField Usertxt;
	
	
//	给table绑定数据
		public void setTable(String name) {
			
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			model.setRowCount(0);//清空
//			获取数据从方法
			List<userInfo> user = new dioUserInfo().ShowUserInfo(name);
//			循环遍历
			for(userInfo u:user) {
				Vector v = new Vector();
				v.add(u.getID());
				v.add(u.getName());
				v.add(u.getAge());
				v.add(u.getSex());
				v.add(u.getPasswd());
				v.add(u.getManage());
				v.add(u.getFulltime());
				v.add(u.getAbsenteeism());
				model.addRow(v);
			}
		}

	/**
	 * Create the frame.
	 */
//	查询个人信息，可以进行模糊查询
	public maPsnalimfor(userInfo user) {
		String name = "";
		setTitle("查询用户信息");
		setIconImage(Toolkit.getDefaultToolkit().getImage(maPsnalimfor.class.getResource("/image/Person.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenuItem mntReturn = new JMenuItem("返回主页面");
		mntReturn.setIcon(new ImageIcon(maPsnalimfor.class.getResource("/image/Return.png")));
		menuBar.add(mntReturn);
		mntReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new frmMain(user).setVisible(true);
				setVisible(false);
			}
		});
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnSearch = new JButton("搜索");
		
		
		Usertxt = new JTextField();
		Usertxt.setColumns(10);
		
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setTable(Usertxt.getText());
			}
		});
		JLabel lblNewLabel = new JLabel("用户名：");
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(17, Short.MAX_VALUE)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 749, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(Usertxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnSearch)
					.addContainerGap(571, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(46)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(Usertxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(lblNewLabel))
						.addComponent(btnSearch))
					.addGap(47)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 158, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(153, Short.MAX_VALUE))
		);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
			},
			new String[] {
				"ID", "Name", "Age", "sex", "passwd", "Manage","Fulltime", "Absenteeism"
			}
		));
		scrollPane.setViewportView(table);
		
		
		
		setTable(name);
		contentPane.setLayout(gl_contentPane);
	}
}
