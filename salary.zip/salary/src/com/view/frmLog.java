package com.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Rectangle;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;



import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextArea;
import java.awt.Window.Type;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JLabel;
import java.awt.Toolkit;

public class frmLog extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	public frmLog() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(frmLog.class.getResource("/image/LOG.png")));
		setTitle("日志系统");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 562);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);//居中
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGap(0, 504, Short.MAX_VALUE)
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGap(0, 338, Short.MAX_VALUE)
		);
		
		JTextArea lab1 = new JTextArea();
		JScrollPane jScrollPane1 = new JScrollPane();
	

//		 setBounds(x,y,width,height); x:组件在容器X轴上的起点 y:组件在容器Y轴上的起点
//		 width:组件的长度 height:组件的高度
		jScrollPane1.setBounds(new Rectangle(22,50, 500, 420));
		jScrollPane1.setBorder(BorderFactory.createEtchedBorder());

		lab1.setFont(new java.awt.Font("楷体_GB2312", Font.BOLD, 10));
		lab1.setText(ImportText());
		lab1.setBounds(new Rectangle(22, 15, 300, 100));
		
		jScrollPane1.setViewportView(lab1);
//		设置文本自动换行		
		lab1.setLineWrap(true);
//		设置滚动面板管理文本域		
		jScrollPane1.setViewportView(lab1);
		lab1.setEditable(false);

		this.getContentPane().add(lab1);
		this.getContentPane().add(jScrollPane1);
		jScrollPane1.setViewportView(lab1);


		contentPane.setLayout(gl_contentPane);
	}
	public String ImportText() {
		String str = "";

		try {
			Scanner scanner = new Scanner(new File("D:\\homeworks\\java\\workspace\\salary\\src\\FileLog\\Log.txt"));
			while (scanner.hasNextLine()) {
				str += scanner.nextLine();
				str+='\n';
			}
		} catch (FileNotFoundException e) {
			System.out.println("file doesn't exist");
		}
		return str;

	}

}
