
package com.view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.dao.RecodeLog;
import com.dao.dioUserInfo;
import com.model.userInfo;

import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;

public class Formalchangepwd extends JFrame {

	/**
	 * 修改密码界面
	 */
	private static final long serialVersionUID = 8345150715458590211L;
	private JPanel contentPane;
	
	private JTextField txtofid;
	private JPasswordField txtofpwd;
	private JPasswordField txtofrepwd;

	/**
	 * Create the frame.
	 */
	public Formalchangepwd(userInfo user) {
		
		setTitle("\u4FEE\u6539\u5BC6\u7801");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Formalchangepwd.class.getResource("/image/Xiugaimima.png")));
		setBounds(100, 100, 450, 249);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		JLabel lblNewLabel = new JLabel("");
//		if(user.getManage()==1)
			lblNewLabel = new JLabel("\u8BF7\u8F93\u5165\u7528\u6237ID\uFF1A");
		
		JLabel lblNewLabel_1 = new JLabel("\u8BF7\u8F93\u5165\u65B0\u7684\u5BC6\u7801\uFF1A");
		
		JLabel lblNewLabel_2 = new JLabel("\u8BF7\u786E\u8BA4\u5BC6\u7801\uFF1A");
//		if(user.getManage()==1) {
			txtofid = new JTextField();
			txtofid.setColumns(10);
//		}
		
		
		txtofpwd = new JPasswordField();
		
		txtofrepwd = new JPasswordField();
		
//		修改密码事件
		JButton btnofyes = new JButton("\u786E\u8BA4");
		btnofyes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				char[] newpwd=txtofpwd.getPassword();
				String strnewpwd=new String(newpwd);
				char[] pwdA=txtofrepwd.getPassword();
				String strrenewpwd=new String(pwdA);
				Pattern pattern =Pattern.compile("[0-9]*");
				if(txtofid.getText().length()<=0) {
					JOptionPane.showMessageDialog(null, "请输入要修改用户的ID");
				}
				else if(txtofpwd.getPassword().length<=0&&txtofrepwd.getPassword().length<=0) {
					JOptionPane.showMessageDialog(null, "请输入密码");
				}
				else if(!pattern.matcher(strnewpwd).matches()||!pattern.matcher(strrenewpwd).matches()||!pattern.matcher(txtofid.getText()).matches()) {
					JOptionPane.showMessageDialog(null, "ID或密码格式不正确(应只包含数字)");
				}
				else if(!strrenewpwd.equals(strnewpwd)) {
					JOptionPane.showMessageDialog(null, "输入密码不一致");
				}
				else if(!(new dioUserInfo().search(Integer.parseInt(txtofid.getText())))) {
					JOptionPane.showMessageDialog(null, "该用户不存在！");
				}
				else {
					String id = String.valueOf(user.getID());
					if(!txtofid.getText().equals(id)&&user.getManage()==0) {
						JOptionPane.showMessageDialog(null, "只能修改自己");
//						日志填写
						new RecodeLog().setLog(user.getName()+"意图修改他人代码，修改密码失败");
						new Formalchangepwd(user).setVisible(true);
						setVisible(false);
					}
					else {
						new dioUserInfo().changePwd(Integer.parseInt(txtofid.getText()), Integer.parseInt(strnewpwd));
//						JOptionPane.showMessageDialog(null,"修改成功");
						setVisible(false);
//						日志填写
						new RecodeLog().setLog(user.getName()+"修改密码成功");
					}
					
				}
			}
		});
		//修改密码的重置按钮事件
		JButton btnofempty = new JButton("\u91CD\u7F6E");
		btnofempty.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtofid.setText("");
				txtofpwd.setText("");
				txtofrepwd.setText("");
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(33)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(txtofrepwd)
								.addComponent(txtofpwd, GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
								.addComponent(txtofid, GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(83)
							.addComponent(btnofyes, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addGap(54)
							.addComponent(btnofempty, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(95, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(42)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(txtofid, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(txtofpwd, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(txtofrepwd, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnofempty)
						.addComponent(btnofyes))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		setResizable(false);
		setLocationRelativeTo(null);
	}

}



