package com.view;

import java.awt.BorderLayout;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.dao.RecodeLog;
import com.model.userInfo;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
/*
 * 主界面
 * */
public class frmMain extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String background = "";
	public ImageIcon icon = new ImageIcon();
	/**
	 * Create the frame.构造函数
	 */
	@SuppressWarnings("removal")
	public frmMain(userInfo user) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(frmMain.class.getResource("/image/Person.png")));
		setTitle("个人主页");
		
//		JOptionPane.showMessageDialog(null, "欢迎"+user.getName()+"登录");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

//		 壁纸
			setBounds(100, 100, 450, 300);
			JPanel contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(50, 50, 50, 50));
			setContentPane(contentPane);
//			 加载图片
			JLabel label = new JLabel();
			background="/image/background"+(int)(Math.random()*12)+".jpg";
//			System.out.println(background);
			icon = new ImageIcon(frmMain.class.getResource(background));
			label.setBounds(0, 0, 1520, 820);
			icon.setImage(icon.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_DEFAULT));
			label.setIcon(icon);
			// 将图片放入label中
			
			// 创建图片类获取图片
//			JFrame frame = new JFrame();
			// 获取图片宽高作为窗体宽高
			setSize(icon.getIconWidth(), icon.getIconHeight());
			// 设置label的大小
			
			// 获取窗口的第二层，将label放入
			getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));
			// 获取frame的顶层容器,并设置为透明
			JPanel j = (JPanel) getContentPane();
			j.setOpaque(false);
			GroupLayout gl_contentPane = new GroupLayout(contentPane);
			gl_contentPane.setHorizontalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGap(0, 1450, Short.MAX_VALUE)
			);
			gl_contentPane.setVerticalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGap(0, 731, Short.MAX_VALUE)
			);
			contentPane.setLayout(gl_contentPane);
			setLocationRelativeTo(null);// 居中
			setResizable(false);
				JMenuBar menuBar = new JMenuBar();
				setJMenuBar(menuBar);
				JMenu xinxi = new JMenu("信息维护");
				xinxi.setIcon(new ImageIcon(frmMain.class.getResource("/image/Weihu.png")));
				menuBar.add(xinxi);
				//退出
				JMenuItem tuichu = new JMenuItem("退出系统");
				tuichu.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Object[] options = {"确定","取消"};
						int Isexit = JOptionPane.showOptionDialog(null, "你确定要离开吗", getTitle(), JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
						if(Isexit==0) {
							new RecodeLog().setLog("用户"+user.getID()+"退出系统");
							System.exit(0);
						}		
					}
				});
				xinxi.add(tuichu);
//				重新登陆
				JMenuItem relogin = new JMenuItem("重新登陆");
				relogin.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new Login().setVisible(true);
					
						setVisible(false);
					}
				});
				xinxi.add(relogin);
//				修改密码
				JMenuItem mntmNewMenuItem_1 = new JMenuItem("修改密码");
				mntmNewMenuItem_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new Formalchangepwd(user).setVisible(true);
					}
				});
				xinxi.add(mntmNewMenuItem_1);
				if(user.getManage()==1) {
//					添加用户
				JMenuItem Add = new JMenuItem("添加用户");
				Add.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new AddUser(user).setVisible(true);
						setVisible(false);
					}
				});
				xinxi.add(Add);
//				删除用户
				JMenuItem delete = new JMenuItem("删除用户");
				delete.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new Frmdelete(user).setVisible(true);
						setVisible(false);
					}
				});
				xinxi.add(delete);
//				修改用户信息
				JMenuItem Amend = new JMenuItem("修改用户信息");
				Amend.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new frmamend(user).setVisible(true);
						setVisible(false);
					}
				});
				xinxi.add(Amend);
				}
				
				
				JMenu consult = new JMenu("信息查询");
				consult.setIcon(new ImageIcon(frmMain.class.getResource("/image/InfoSearch.png")));
				menuBar.add(consult);
//				个人信息
				JMenuItem personal = new JMenuItem("个人信息");
				personal.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
//						日志填写
						new RecodeLog().setLog(user.getID()+"查询个人信息");
						if(user.getManage()==1) {
//							System.out.println(user.getManage());
							new maPsnalimfor(user).setVisible(true);
						}
						else {
//							System.out.println(user.getManage());
							new Psnalimfor(user).setVisible(true);
						}
							
						setVisible(false);
					}
				});
				consult.add(personal);
//				薪资
				JMenuItem wage = new JMenuItem("薪资信息");
				wage.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
//						日志填写
						new RecodeLog().setLog(user.getID()+"查询薪资信息");
						if(user.getManage()==1) {
							new MaWage(user).setVisible(true);
						}
						else {
							new PrWage(user).setVisible(true);
						}
						setVisible(false);
					}
				});
				consult.add(wage);
			

				if(user.getManage()==0) {
					JMenu opinion = new JMenu("意见反馈");
				opinion.setIcon(new ImageIcon(frmMain.class.getResource("/image/Suggestion.png")));
				menuBar.add(opinion);
//				意见填写
				JMenuItem yijian = new JMenuItem("意见填写");
				yijian.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new Suggestion(user).setVisible(true);
					}
				});
				opinion.add(yijian);
				}
				
				if(user.getManage()==1) {
					JMenu mnNewMenu = new JMenu("工作日志");
				mnNewMenu.setIcon(new ImageIcon(frmMain.class.getResource("/image/LOG.png")));
				menuBar.add(mnNewMenu);
				
				JMenuItem mntmNewMenuItem = new JMenuItem("查看");
				mntmNewMenuItem.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new frmLog().setVisible(true);
					}
				});
				mnNewMenu.add(mntmNewMenuItem);
				}
//				界面刷新
				JMenu mnNewMenu_1 = new JMenu("");
				mnNewMenu_1.setIcon(new ImageIcon(frmMain.class.getResource("/image/shuaxin.png")));
				menuBar.add(mnNewMenu_1);
				JMenuItem mntmNewMenuItem_2 = new JMenuItem("刷新");
				mntmNewMenuItem_2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
				mntmNewMenuItem_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						background="/image/background"+(int)(Math.random()*12)+".jpg";
//						System.out.println(background);
						icon = new ImageIcon(frmMain.class.getResource(background));
						label.setBounds(0, 0, 1520, 820);
						icon.setImage(icon.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_DEFAULT));
						label.setIcon(icon);
					}
				});
				mnNewMenu_1.add(mntmNewMenuItem_2);
//				frame.setVisible(true);

	}
}
