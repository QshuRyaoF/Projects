package com.view;
/*
 * 修改用户信息
 * */
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.dao.RecodeLog;
import com.dao.dioUserInfo;
import com.model.userInfo;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;

public class frmamend extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField UpdateText;
	private JTextField ID;

	public void setUpdate(String id, String type, String s) {

		
		new dioUserInfo().Amend(id, type, s);

	}
	public String Str(String type) {
		String RET = type;
		return RET;
	}

	/**
	 * Create the frame.
	 */
	public frmamend(userInfo user) {
		setTitle("修改页面");
		setIconImage(Toolkit.getDefaultToolkit().getImage(frmamend.class.getResource("/image/Xiugai.png")));
		setBackground(new Color(240, 240, 240));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 727, 583);
		setLocationRelativeTo(null);// ����
		setResizable(false);// ��ֹ�϶��͸ı䴰���С
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("返回主页面");
		mntmNewMenuItem.setIcon(new ImageIcon(frmamend.class.getResource("/image/Return.png")));
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new frmMain(user).setVisible(true);
				setVisible(false);
			}
		});
		menuBar.add(mntmNewMenuItem);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		UpdateText = new JTextField();
		UpdateText.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("\u4FEE\u6539\u4FE1\u606F\uFF1A");
		lblNewLabel_1.setFont(new Font("�����ֺ��μ���", Font.PLAIN, 16));

		ID = new JTextField();
		ID.setColumns(10);

		JLabel lblNewLabel = new JLabel("ID\uFF1A");
		lblNewLabel.setFont(new Font("�����ֺ��μ���", Font.PLAIN, 17));

		JLabel lblNewLabel_2 = new JLabel("\u4FEE\u6539\u4E3A\uFF1A");
		lblNewLabel_2.setFont(new Font("�����ֺ��μ���", Font.PLAIN, 17));
		JCheckBox check = new JCheckBox("\u786E\u8BA4");
		String[] ct = {"姓名", "年龄", "性别", "密码", "全勤", "缺勤次数", "基本工资"};

		JComboBox getnews = new JComboBox(ct);
		getnews.setBackground(new Color(240, 248, 255));
		getnews.setModel(new DefaultComboBoxModel(new String[] {"姓名", "年龄", "性别", "密码", "全勤", "缺勤次数", "基本工资"}));
		panel.add(getnews);

		JScrollPane scrollPane = new JScrollPane();
		panel.add(scrollPane);

		JList jList = new JList(ct);
		JList lt = jList;
		lt.setVisibleRowCount(4);
		JScrollPane jsp1 = new JScrollPane(lt);

		

		// �޸���Ϣȷ�ϰ�ť

		check.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				String newID = ID.getText();
				String newText = UpdateText.getText();
				Pattern pattern = Pattern.compile("[0-9]*");
				if (newID.length() <= 0) {
					JOptionPane.showMessageDialog(null, "ID不能为空");
				} else if (!(new dioUserInfo().search(Integer.parseInt(newID)))) {
					JOptionPane.showMessageDialog(null, "该用户不存在");
					new RecodeLog().setLog("由于该用户不存在修改用户"+ID.getText()+"信息失败");
				} else if (newText.length() <= 0 && newText.length() <= 0) {
					JOptionPane.showMessageDialog(null, "请输入修改的信息");
				} else if (!pattern.matcher(newID).matches()||ID.getText().length()>=11) {
					JOptionPane.showMessageDialog(null, "ID格式不正确)");
					new RecodeLog().setLog("由于ID格式不正确修改用户"+ID.getText()+"信息失败");
				} else {
					String city = getnews.getSelectedItem().toString();
					new dioUserInfo().Amend(newID, city, newText);
//					日志填写
					new RecodeLog().setLog("修改用户"+ID.getText()+Str(city));
					JOptionPane.showMessageDialog(null, "修改成功");
				}
				JOptionPane.showMessageDialog(null, "修改成功");
				// ��ת����ҳ
				new frmMain(user).setVisible(true);
				// ���ص�ǰ����
				setVisible(false);
			}
		});
		check.setBackground(Color.WHITE);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(121)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
							.addGap(41)
							.addComponent(ID, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewLabel_1)
							.addGap(18)
							.addComponent(panel, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(UpdateText, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE)
							.addGap(26)
							.addComponent(check, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(61)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(2)
							.addComponent(lblNewLabel))
						.addComponent(ID, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(1)
							.addComponent(lblNewLabel_2))
						.addComponent(UpdateText, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(4)
							.addComponent(check))))
		);
		contentPane.setLayout(gl_contentPane);

	}
}
