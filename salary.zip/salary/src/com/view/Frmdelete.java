package com.view;
/*
 * 删除用户
 * */
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.dao.RecodeLog;
import com.dao.dioUserInfo;
import com.model.userInfo;

public class Frmdelete extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField deleteID;
	private JCheckBox queren;
	private JCheckBox quxiao;

	/**
	 * Create the frame.
	 */
	public Frmdelete(userInfo user) {
		setTitle("\u5220\u9664\u7528\u6237");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Frmdelete.class.getResource("/image/Delete.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setLocationRelativeTo(null);// ����
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblNewLabel = new JLabel("ID:");
		lblNewLabel.setFont(new Font("�����ֺ��μ���", Font.PLAIN, 16));

		deleteID = new JTextField();
		deleteID.setColumns(10);
		// ȷ��ɾ��
		queren = new JCheckBox("\u786E\u8BA4\u5220\u9664");
		queren.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String delete = deleteID.getText();
				if (delete.length() <= 0) {
					JOptionPane.showMessageDialog(null, "ID不可为空");
				} else if (!(new dioUserInfo().search(Integer.parseInt(delete)))) {
					JOptionPane.showMessageDialog(null, "该用户不存在");
				} else {
					Boolean flag =new dioUserInfo().deleteuser(Integer.parseInt(delete),user);
					if(flag==true) {
						JOptionPane.showMessageDialog(null, "删除成功");
//						日志填写
						new RecodeLog().setLog("删除用户:"+Integer.parseInt(delete));
						new frmMain(user).setVisible(true);
						// ���ص�ǰ����
						setVisible(false);
					}
					else {
						new Frmdelete(user).setVisible(true);
						setVisible(false);
					}
				}
			}
		});
		queren.setBackground(Color.WHITE);
		// ȡ��
		quxiao = new JCheckBox("\u53D6\u6D88");
		quxiao.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// ��ת����ҳ
				new frmMain(user).setVisible(true);
				// ���ص�ǰ����
				setVisible(false);
			}
		});
		quxiao.setBackground(Color.WHITE);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup().addGap(112)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(queren, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
								.addGap(30).addComponent(quxiao, 0, 0, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.UNRELATED)
								.addComponent(deleteID, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE)))
				.addContainerGap(125, Short.MAX_VALUE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addGap(79)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(deleteID, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel))
						.addGap(29).addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(quxiao)
								.addComponent(queren))
						.addContainerGap(99, Short.MAX_VALUE)));
		contentPane.setLayout(gl_contentPane);
	}
}
