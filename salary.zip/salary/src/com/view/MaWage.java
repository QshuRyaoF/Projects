package com.view;
/*
 * 薪资待遇页面
 * */
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.dao.dioUserInfo;
import com.model.userInfo;

import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class MaWage extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;

//	展示员工薪资信息
	public void setTable(String name) {
		
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);//清空
//		获取数据层方法
		List<userInfo> user = new dioUserInfo().ShowUserInfo(name);
//		循环遍历
		for(userInfo u:user) {
			Double fiveGold = null;
//			养老保险基本工资的10%，医疗保险基本工资的10%，失业保险基本工资的1.5%，工商保险基本工资的0.5%，生育保险基本工资的1%，住房工资金基本工资7%，该部分由公司缴纳
			fiveGold = u.getSalary()*0.1+u.getSalary()*0.1+u.getSalary()*0.015+u.getSalary()*0.005+u.getSalary()*0.01+u.getSalary()*0.07;
			Vector v = new Vector();
			v.add(u.getID());
			v.add(u.getName());
			v.add(u.getSalary());
			v.add(30-u.getAbsenteeism());
			v.add(u.getSalary());
			v.add(u.getAmountofRewards());
			v.add(u.getManage()==1?5000:2000);
			v.add((30-u.getAbsenteeism())*100);
			Double sumDouble=u.getSalary()+u.getAmountofRewards()+(u.getManage()==1?5000:2000)-u.getAbsenteeism()*100;
			v.add(sumDouble);
			v.add(u.getAmountofPenalties()+u.getAbsenteeism()*100);
			Double prfiveGoDouble = u.getSalary()*0.08+u.getSalary()*0.02+u.getSalary()*0.005+u.getSalary()*0.07;
			Double taxDouble = sumDouble>=5000?(sumDouble-prfiveGoDouble-5000):0;
			Double quickKouchushu = new dioUserInfo().check(taxDouble) ;
			v.add(quickKouchushu);
			v.add(fiveGold);
			v.add(sumDouble-u.getAmountofPenalties()-fiveGold-quickKouchushu);
			model.addRow(v);
		}
	}
	/**
	 * Create the frame.
	 */
	public MaWage(userInfo user) {
		String name = "";
		setTitle("薪资界面");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MaWage.class.getResource("/image/Taxes.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1034, 573);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);// 居中
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("返回主页面");
		mntmNewMenuItem.setIcon(new ImageIcon(MaWage.class.getResource("/image/Return.png")));
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new frmMain(user).setVisible(true);;
				setVisible(false);
			}
		});
		menuBar.add(mntmNewMenuItem);
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JLabel lblNewLabel = new JLabel("用户名：");
		
		textField = new JTextField();
		textField.setColumns(10);
//		可以模糊查询
		JButton btnNewButton = new JButton("搜索");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setTable(textField.getText());
			}
		});
		
		JLabel lblNewLabel_1 = new JLabel("养老保险基本工资的10%，医疗保险基本工资的10%，失业保险基本工资的1.5%，工商保险基本工资的0.5%，生育保险基本工资的1%，住房工资金基本工资7%");
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(22)
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnNewButton))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel_1))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 990, Short.MAX_VALUE)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(61)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addGap(52)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 193, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
					.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
					.addGap(57))
		);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"\u7528\u6237ID", "\u59D3\u540D", "\u57FA\u672C\u5DE5\u8D44", "\u52A0\u73ED\u5929\u6570", "\u5DE5\u8D44", "\u6708\u5956\u91D1", "\u804C\u52A1\u8865\u8D34", "\u52A0\u73ED\u5DE5\u8D44", "\u5408\u8BA1", "\u7F3A\u52E4\u7F5A\u91D1", "\u4E2A\u7A0E", "\u4E94\u9669\u4E00\u91D1", "\u5B9E\u53D1\u5DE5\u8D44"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, true, true, true, true, true, true, true, true, false, true, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		setTable(name);
		contentPane.setLayout(gl_contentPane);
	}
}
