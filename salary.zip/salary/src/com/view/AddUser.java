package com.view;
/*
 * 娣诲姞鐢ㄦ埛鐣岄潰
 * */


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.dao.RecodeLog;
import com.dao.dioUserInfo;
import com.model.userInfo;
import com.mysql.jdbc.Connection;
import com.util.DbUtil;

import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenuBar;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;

public class AddUser extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField AddID;
	private JTextField AddName;
	private JTextField AddAge;
	private JTextField Addsex;
	private JTextField Addpawd;
	private JTextField AddSalary;
	private JTextField AddFulltime;
	private JTextField AddAbsenteeism;
	private JTextField AddAmountofRewards;
	private JTextField AddAmountofPenalties;
	private JLabel lblID;
	private JLabel lblAge;
	private JLabel lblName;
	private JLabel lblsex;
	private JLabel lblpawd;
	private JLabel lblSalary;
	private JLabel lblFulltime;
	private JLabel lblNewLabel;
	private JLabel lblRewards;
	private JLabel lblPenalties;
	private JButton btnNext;

//	鏁版嵁搴撶殑杩炴帴瀛楃涓�
	private String dbUrl="jdbc:mysql://localhost:330/salary";
//	鏁版嵁搴撶櫥褰曠敤鎴峰悕鍜屽瘑鐮�
	private String dbName = "root";
	private String dbPwd = "2020110420#lll";
//	鍒涘缓椹卞姩
	private String jdbcName = "com.mysql.jdbc.Driver";
	private JLabel lblNewLabel_1;
	private JTextField AddManage;


	/**
	 * Create the frame.
	 */
	public AddUser(userInfo userManager) {
		setTitle("鐢ㄦ埛娣诲姞");
		setIconImage(Toolkit.getDefaultToolkit().getImage(AddUser.class.getResource("/image/AddUser.png")));
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 636, 499);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);//灞呬腑
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("杩斿洖涓婚〉闈�");
		mntmNewMenuItem.setIcon(new ImageIcon(AddUser.class.getResource("/image/Return.png")));
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new frmMain(userManager).setVisible(true);
				setVisible(false);
			}
		});
		menuBar.add(mntmNewMenuItem);
		setContentPane(contentPane);
		
		AddID = new JTextField();
		AddID.setColumns(20);
		
		AddName = new JTextField();
		AddName.setColumns(20);
		
		AddAge = new JTextField();
		AddAge.setColumns(20);
		
		Addsex = new JTextField();
		Addsex.setColumns(20);
		
		Addpawd = new JTextField();
		Addpawd.setColumns(20);
		
		AddSalary = new JTextField();
		AddSalary.setColumns(20);
		
		AddFulltime = new JTextField();
		AddFulltime.setColumns(20);
		
		AddAbsenteeism = new JTextField();
		AddAbsenteeism.setColumns(20);
		
		AddAmountofRewards = new JTextField();
		AddAmountofRewards.setColumns(20);
		
		AddAmountofPenalties = new JTextField();
		AddAmountofPenalties.setColumns(20);
		
		lblID = new JLabel("鍛樺伐ID锛�");
		
		lblAge = new JLabel("骞�  榫勶細");
		
		lblName = new JLabel("濮�  鍚嶏細");
		
		lblsex = new JLabel("鎬�  鍒細");
		
		lblpawd = new JLabel("瀵�  鐮侊細");
		
		lblSalary = new JLabel("宸�  璧勶細");
		
		lblFulltime = new JLabel("鍏�  鍕わ細");
		
		lblNewLabel = new JLabel("缂哄嫟娆℃暟锛�");
		
		lblRewards = new JLabel("濂栭噾鏁伴锛�");
		
		lblPenalties = new JLabel("缃氶噾鏁伴锛�");
		userInfo user = new userInfo();
		try (Connection connection = new DbUtil().getConn()) {
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JButton btnFinish = new JButton("娣诲姞瀹屾瘯");
		btnFinish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(AddID.getText().length()<=0||AddName.getText().length()<=0) {
					JOptionPane.showMessageDialog(null, "娣诲姞ID鍜岀敤鎴峰悕涓嶈兘涓虹┖锛�");
					new AddUser(userManager).setVisible(true);
					setVisible(false);
				}
				else {
					if(new dioUserInfo().search(Integer.parseInt(AddID.getText()))==true) {
						JOptionPane.showMessageDialog(null, "娣诲姞ID宸茬粡瀛樺湪锛�");
						new AddUser(userManager).setVisible(true);
						setVisible(false);
					}
					else {
						user.setID(Integer.parseInt(AddID.getText()));
						user.setName(AddName.getText());
						user.setAge(Integer.parseInt(AddAge.getText().length()<=0?"0":AddAge.getText()));
						user.setSex(Addsex.getText().length()<=0?"null":Addsex.getText());
						user.setPasswd(Addpawd.getText().length()<=0?"123456":Addpawd.getText());
						user.setManage(Integer.parseInt(AddManage.getText().length()<=0?"0":AddManage.getText()));
						user.setSalary(Double.parseDouble(AddSalary.getText().length()<=0?"1000":AddSalary.getText()));
						user.setFulltime(AddFulltime.getText().length()<=0?"鏄�":AddFulltime.getText());
						user.setAbsenteeism(Integer.parseInt(AddAbsenteeism.getText().length()<=0?"0":AddAbsenteeism.getText()));
						user.setAmountofRewards(Double.parseDouble(AddAmountofRewards.getText().length()<=0?"0":AddAmountofRewards.getText()));
						user.setAmountofPenalties(Double.parseDouble(AddAmountofPenalties.getText().length()<=0?"0":AddAmountofPenalties.getText()));
						new dioUserInfo().Adduser(user);
//						鏃ュ織濉啓
						new RecodeLog().setLog("娣诲姞鐢ㄦ埛:"+user.getID());
						new frmMain(userManager).setVisible(true);
						setVisible(false);
					}	
				}
			}
		});
		btnNext = new JButton("涓嬩竴娣诲姞");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				灏嗗凡杈撳叆鐨勬暟鎹瓨鍏ユ暟鎹簱
				if(AddID.getText().length()<=0||AddName.getText().length()<=0) {
					JOptionPane.showMessageDialog(null, "娣诲姞ID鍜岀敤鎴峰悕涓嶈兘涓虹┖锛�");
					new AddUser(userManager).setVisible(true);
					setVisible(false);
				}
				else {
					if(new dioUserInfo().search(Integer.parseInt(AddID.getText()))==true) {
						JOptionPane.showMessageDialog(null, "娣诲姞ID宸茬粡瀛樺湪锛�");
						new AddUser(userManager).setVisible(true);
						setVisible(false);
					}
					else {
						user.setID(Integer.parseInt(AddID.getText()));
						user.setName(AddName.getText());
						user.setAge(Integer.parseInt(AddAge.getText().length()<=0?"0":AddAge.getText()));
						user.setSex(Addsex.getText().length()<=0?"null":Addsex.getText());
						user.setPasswd(Addpawd.getText().length()<=0?"123456":Addpawd.getText());
						user.setManage(Integer.parseInt(AddManage.getText().length()<=0?"0":AddManage.getText()));
						user.setSalary(Double.parseDouble(AddSalary.getText().length()<=0?"1000":AddSalary.getText()));
						user.setFulltime(AddFulltime.getText().length()<=0?"鏄�":AddFulltime.getText());
						user.setAbsenteeism(Integer.parseInt(AddAbsenteeism.getText().length()<=0?"0":AddAbsenteeism.getText()));
						user.setAmountofRewards(Double.parseDouble(AddAmountofRewards.getText().length()<=0?"0":AddAmountofRewards.getText()));
						user.setAmountofPenalties(Double.parseDouble(AddAmountofPenalties.getText().length()<=0?"0":AddAmountofPenalties.getText()));
//						鏃ュ織濉啓
						new RecodeLog().setLog("娣诲姞鐢ㄦ埛:"+user.getID());
						new dioUserInfo().Adduser(user);

					}	
				}
//				娓呯┖妗嗗唴鍐呭
				AddID.setText("");
				AddName.setText("");
				AddAge.setText("");
				Addsex.setText("");
				Addpawd.setText("");
				AddSalary.setText("");
				AddFulltime.setText("");
				AddAbsenteeism.setText("");
				AddAmountofRewards.setText("");
				AddAmountofPenalties.setText("");
				AddManage.setText("");
				
			}
		});
		
		lblNewLabel_1 = new JLabel("鏄惁娣诲姞涓虹鐞嗗憳锛�");
		
		AddManage = new JTextField();
		AddManage.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(174)
							.addComponent(btnFinish)
							.addGap(39)
							.addComponent(btnNext))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(10)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblSalary, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(AddSalary, 0, 0, Short.MAX_VALUE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblpawd, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(Addpawd, 0, 0, Short.MAX_VALUE))
								.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
									.addComponent(lblsex, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(Addsex, 0, 0, Short.MAX_VALUE))
								.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
									.addComponent(lblAge, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(AddAge, 0, 0, Short.MAX_VALUE))
								.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
									.addComponent(lblName, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(AddName, 0, 0, Short.MAX_VALUE))
								.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
									.addComponent(lblID, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(AddID, GroupLayout.PREFERRED_SIZE, 96, GroupLayout.PREFERRED_SIZE)))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
											.addGroup(gl_contentPane.createSequentialGroup()
												.addGap(129)
												.addComponent(lblFulltime, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE))
											.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
												.addGap(127)
												.addComponent(lblNewLabel)))
										.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
											.addGap(127)
											.addComponent(lblRewards)))
									.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
										.addGap(127)
										.addComponent(lblPenalties)))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(116)
									.addComponent(lblNewLabel_1)))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(AddManage)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
									.addComponent(AddAmountofPenalties, 0, 0, Short.MAX_VALUE)
									.addComponent(AddAmountofRewards, Alignment.LEADING, 0, 0, Short.MAX_VALUE)
									.addComponent(AddAbsenteeism, Alignment.LEADING, 0, 0, Short.MAX_VALUE)
									.addComponent(AddFulltime, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 94, Short.MAX_VALUE)))
							.addGap(32)))
					.addGap(316))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(72)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(6)
									.addComponent(lblID))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(3)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
										.addComponent(lblFulltime)
										.addComponent(AddFulltime, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(75)
							.addComponent(AddID, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(21)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(3)
							.addComponent(lblName))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(3)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel)
								.addComponent(AddAbsenteeism, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addComponent(AddName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(21)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblAge)
								.addComponent(lblRewards)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(18)
							.addComponent(AddAge, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(18)
							.addComponent(AddAmountofRewards, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(21)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblsex)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
									.addComponent(lblPenalties)
									.addComponent(AddAmountofPenalties, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(18)
							.addComponent(Addsex, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(3)
							.addComponent(lblpawd))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(3)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel_1)
								.addComponent(AddManage, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addComponent(Addpawd, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(24)
							.addComponent(lblSalary))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(21)
							.addComponent(AddSalary, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(40)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnFinish)
								.addComponent(btnNext))))
					.addGap(13))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
