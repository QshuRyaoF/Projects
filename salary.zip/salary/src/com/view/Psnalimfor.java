package com.view;
/*
 * 员工查看本人信息界面
 * */


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.dao.dioUserInfo;
import com.model.userInfo;
import javax.swing.JScrollPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.List;
import java.util.Vector;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class Psnalimfor extends JFrame {

	private JPanel contentPane;
	private JTable table = new JTable();

//	展示员工个人信息
	public void setTable(String name) {
		
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);//清空
//		获取数据层方法
		List<userInfo> user = new dioUserInfo().ShowUserInfo(name);
//		循环遍历
		for(userInfo u:user) {
			Vector v = new Vector();
			v.add(u.getID());
			v.add(u.getName());
			v.add(u.getAge());
			v.add(u.getSex());
			v.add(u.getPasswd());
			v.add(u.getManage());
			v.add(u.getFulltime());
			v.add(u.getAbsenteeism());
			model.addRow(v);
		}
	}
	/**
	 * Create the frame.
	 */
	public Psnalimfor(userInfo user) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Psnalimfor.class.getResource("/image/Person.png")));
		String name = user.getName();
		setTitle("员工"+user.getName());
		setLocationRelativeTo(null);// ����
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 801, 502);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("返回主页面");
		mntmNewMenuItem.setIcon(new ImageIcon(Psnalimfor.class.getResource("/image/Return.png")));
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new frmMain(user).setVisible(true);
				setVisible(false);
			}
		});
		menuBar.add(mntmNewMenuItem);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JLabel lblNewLabel = new JLabel("用户："+user.getName());
		lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 15));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 152, GroupLayout.PREFERRED_SIZE)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 750, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(17, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(69)
					.addComponent(lblNewLabel)
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(306, Short.MAX_VALUE))
		);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null},
			},
			new String[] {
				"Id", "Name", "Age", "sex", "passwd", "Manage", "Fulltime", "Absenteeism"
			}
		));
		scrollPane.setViewportView(table);
		setTable(name);
		contentPane.setLayout(gl_contentPane);
	}

}
