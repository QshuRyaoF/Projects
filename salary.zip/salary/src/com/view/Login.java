package com.view;
/*
 * 登录界面
 * 创建日期2021/12/27
 * */

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.dao.RecodeLog;
import com.dao.dioUserInfo;
import com.model.userInfo;

import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Login extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtField;
	private JPasswordField paswField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/image/loginImg.png")));
		setTitle("登录");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 561);
		setLocationRelativeTo(null);//居中
		setResizable(false);//禁止拖动和改变窗体大小
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 196, 222));
		contentPane.setBorder(new EmptyBorder(4, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lbl = new JLabel("牛牛财务管理系统");
		lbl.setFont(new Font("华文新魏", Font.PLAIN, 50));
		
		txtField = new JTextField();
		//用户名文本框的键盘监听
		txtField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int KeyCode=e.getKeyCode();
				if(KeyCode==10) {
					dologin();
				}
			}
		});
		txtField.setColumns(20);
		
		paswField = new JPasswordField();
		//密码框的键盘监听
		paswField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int KeyCode=e.getKeyCode();
				if(KeyCode==10) {
					dologin();
				}
			}
		});
		paswField.setEchoChar('*');
		JLabel lbl1 = new JLabel("用户ID：");
		lbl1.setIcon(new ImageIcon(Login.class.getResource("/image/userimag.png")));
		lbl1.setFont(new Font("楷体", Font.PLAIN, 20));
		
		JLabel lbl2 = new JLabel("密  码：");
		lbl2.setIcon(new ImageIcon(Login.class.getResource("/image/paswimag.png")));
		lbl2.setFont(new Font("楷体", Font.PLAIN, 20));
		
		JButton btnLogin = new JButton("Login");
		//键盘回车监听
		btnLogin.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int KeyCode=e.getKeyCode();
				if(KeyCode==10) {
					dologin();
				}
			}
		});
//		登录事件
		//按钮监听
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				正则表达式
				dologin();
			}
		});
		btnLogin.setIcon(new ImageIcon(Login.class.getResource("/image/btnlogin.png")));
		btnLogin.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 15));
		
		JButton btnReset = new JButton("Reset");
//		重置按钮事件
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtField.setText("");//清空用户名
				paswField.setText("");//清空密码框
			}
		});
		btnReset.setIcon(new ImageIcon(Login.class.getResource("/image/btnreset.png")));
		btnReset.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 15));
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Login.class.getResource("/image/Image-1.png")));
		
		JLabel lbl_3 = new JLabel("ChengDUBestTEAM");
		lbl_3.setFont(new Font("Showcard Gothic", Font.PLAIN, 20));
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/image/BlackRoom.png")));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(27)
					.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 268, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lbl1)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(txtField, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lbl2)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnLogin)
									.addGap(61)
									.addComponent(btnReset))
								.addComponent(paswField, GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE))))
					.addGap(47))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(667, Short.MAX_VALUE)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
					.addGap(21))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(59)
					.addComponent(lbl_3, GroupLayout.PREFERRED_SIZE, 194, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(493, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(168, Short.MAX_VALUE)
					.addComponent(lbl, GroupLayout.PREFERRED_SIZE, 427, GroupLayout.PREFERRED_SIZE)
					.addGap(151))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(69)
					.addComponent(lbl)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lbl1)
								.addComponent(txtField, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
							.addGap(44)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lbl2)
								.addComponent(paswField, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE))
							.addGap(50)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnReset)
								.addComponent(btnLogin)))
						.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 260, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lbl_3)
					.addPreferredGap(ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
					.addComponent(lblNewLabel)
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
	public void dologin() {
		java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("[0-9]*");
		if(txtField.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "用户名不能为空！");
		}
		if(!pattern.matcher(txtField.getText()).matches()) {
			JOptionPane.showMessageDialog(null, "用户ID只能是0~9的数字组成");
		}
		else if(paswField.getPassword().length<=0) {
			JOptionPane.showMessageDialog(null, "密码不能为空！");
		}
		else {
			if(txtField.getText().length()>=11) {
				JOptionPane.showMessageDialog(null, "用户名长度不可超过10位，请重新输入");
				txtField.setText("");//清空用户名
				paswField.setText("");//清空密码框
			}
			else {
//				JOptionPane.showMessageDialog(null, "欢迎用户登录");
				char[] newPwd = paswField.getPassword();
				String strPwd = new String(newPwd); 
				userInfo newinfo = new userInfo();
				int newid = Integer.parseInt(txtField.getText());
				newinfo.setID(newid);
				newinfo.setPasswd(strPwd);
//				获取返回的数据
				userInfo info = new dioUserInfo().Login(newinfo);
				System.out.println(info.getManage());
				if(info.getName()!=null) {
					new RecodeLog().setLog("用户"+txtField.getText()+"登录");//日志填写
//				登录成功，跳转到【主窗口】		
					new frmMain(info).setVisible(true);
					setVisible(false);

				}
				else {
					JOptionPane.showMessageDialog(null, "密码或用户名输入错误！");
//					日志填写
					new RecodeLog().setLog("登录失败");
				}
			}
		}
	}
}
